/* ============================================================
   БРАТИК ОПС — 3D SHOOTER  ·  Three.js  ·  всё в одном файле
   ============================================================ */
(function () {
'use strict';

const V3 = THREE.Vector3;
const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
const lerp = (a, b, t) => a + (b - a) * t;
const rand = (a, b) => a + Math.random() * (b - a);
const randi = (a, b) => Math.floor(rand(a, b + 1));
const choose = arr => arr[Math.floor(Math.random() * arr.length)];

/* ---------------------------------------------------------- AUDIO ---- */
const AudioSys = (() => {
  let ctx = null, master = null, noiseBuf = null, on = true;
  function init() {
    if (ctx) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    ctx = new AC();
    master = ctx.createGain(); master.gain.value = 0.45; master.connect(ctx.destination);
    const len = ctx.sampleRate * 1.2;
    noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
  }
  function noise(dur, freq, q, gain, type) {
    if (!ctx || !on) return;
    const src = ctx.createBufferSource(); src.buffer = noiseBuf;
    src.playbackRate.value = 1;
    const f = ctx.createBiquadFilter(); f.type = type || 'bandpass'; f.frequency.value = freq; f.Q.value = q;
    const g = ctx.createGain();
    const t = ctx.currentTime;
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
    src.connect(f); f.connect(g); g.connect(master);
    src.start(t); src.stop(t + dur + 0.02);
  }
  function tone(freq, dur, gain, type, slideTo) {
    if (!ctx || !on) return;
    const o = ctx.createOscillator(); o.type = type || 'sine';
    const g = ctx.createGain(); const t = ctx.currentTime;
    o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
    o.connect(g); g.connect(master); o.start(t); o.stop(t + dur + 0.02);
  }
  return {
    init,
    toggle() { on = !on; if (master) master.gain.value = on ? 0.45 : 0; return on; },
    isOn() { return on; },
    shot(kind) {
      if (kind === 'sniper') { noise(0.35, 320, 0.6, 0.9, 'lowpass'); tone(90, 0.28, 0.35, 'square', 40); }
      else if (kind === 'shotgun') { noise(0.3, 700, 0.7, 0.85, 'lowpass'); tone(120, 0.2, 0.3, 'sawtooth', 50); }
      else if (kind === 'pistol') { noise(0.1, 1500, 1.1, 0.45); tone(220, 0.07, 0.15, 'square', 90); }
      else { noise(0.11, 1100, 0.9, 0.5); tone(160, 0.08, 0.18, 'square', 70); }
    },
    enemyShot() { noise(0.1, 900, 1.4, 0.12, 'highpass'); },
    hit() { tone(1250, 0.05, 0.12, 'square'); },
    head() { tone(1900, 0.09, 0.16, 'triangle', 2400); tone(900, 0.12, 0.1, 'sine'); },
    kill() { tone(520, 0.08, 0.14, 'triangle', 780); setTimeout(() => tone(780, 0.12, 0.12, 'triangle', 1040), 70); },
    reload() { noise(0.05, 2400, 2, 0.16, 'highpass'); setTimeout(() => noise(0.06, 1200, 2, 0.18, 'highpass'), 220); },
    empty() { noise(0.03, 3200, 3, 0.2, 'highpass'); },
    hurt() { tone(150, 0.22, 0.3, 'sawtooth', 60); },
    wave() { tone(320, 0.5, 0.18, 'sawtooth', 160); setTimeout(() => tone(240, 0.6, 0.16, 'sawtooth', 120), 260); },
    noammo() { tone(300, 0.05, 0.1, 'square', 200); }
  };
})();

/* ------------------------------------------------------- RENDERER ---- */
const canvas = document.getElementById('game');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.05;

const scene = new THREE.Scene();
scene.fog = new THREE.Fog(0xc8d2da, 75, 215);
(function sky() {
  const tex = canvasTex(64, 512, (g, w, h) => {
    const grd = g.createLinearGradient(0, 0, 0, h);
    grd.addColorStop(0.0, '#e9e0cd');
    grd.addColorStop(0.20, '#d8dcda');
    grd.addColorStop(0.40, '#aec8da');
    grd.addColorStop(0.66, '#6f9ec4');
    grd.addColorStop(1.0, '#2f5f92');
    g.fillStyle = grd; g.fillRect(0, 0, w, h);
    // облачка
    for (let i = 0; i < 26; i++) {
      const y = rand(40, h * 0.55), x = rand(0, w), r = rand(6, 20);
      const cg = g.createRadialGradient(x, y, 0, x, y, r);
      cg.addColorStop(0, 'rgba(255,255,255,' + rand(.25, .6) + ')');
      cg.addColorStop(1, 'rgba(255,255,255,0)');
      g.fillStyle = cg; g.beginPath(); g.arc(x, y, r, 0, 7); g.fill();
    }
  });
  tex.wrapS = tex.wrapT = THREE.ClampToEdgeWrapping;
  const bg = new THREE.Mesh(
    new THREE.SphereGeometry(300, 32, 20),
    new THREE.MeshBasicMaterial({ map: tex, side: THREE.BackSide, fog: false, depthWrite: false, depthTest: false })
  );
  bg.renderOrder = -1000;
  scene.add(bg);
  scene.userData.sky = bg;
  scene.background = new THREE.Color(0xb9c8d4);
})();

const camera = new THREE.PerspectiveCamera(75, innerWidth / innerHeight, 0.08, 400);
camera.rotation.order = 'YXZ';

// отдельная сцена для оружия (без клиппинга в стены)
const gunScene = new THREE.Scene();
const gunCam = new THREE.PerspectiveCamera(58, innerWidth / innerHeight, 0.01, 12);
gunScene.add(new THREE.HemisphereLight(0xffffff, 0x556070, 1.6));
const gunDir = new THREE.DirectionalLight(0xfff0dd, 2.2); gunDir.position.set(0.6, 1, 0.9); gunScene.add(gunDir);
const gunRim = new THREE.DirectionalLight(0x88bbff, 1.4); gunRim.position.set(-1, 0.4, -1); gunScene.add(gunRim);
const muzzleLight = new THREE.PointLight(0xffc070, 0, 3, 2); gunScene.add(muzzleLight);

/* --------------------------------------------------------- LIGHTS ---- */
const hemi = new THREE.HemisphereLight(0xdceaf5, 0x5a5145, 1.0); scene.add(hemi);
const sun = new THREE.DirectionalLight(0xffe8c8, 2.1);
sun.position.set(-32, 46, 24);
sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
const sc = sun.shadow.camera;
sc.left = -50; sc.right = 50; sc.top = 50; sc.bottom = -50; sc.near = 1; sc.far = 160;
sun.shadow.bias = -0.0008;
scene.add(sun);
scene.add(sun.target);
const fill = new THREE.DirectionalLight(0x8fb6d8, 0.55); fill.position.set(28, 22, -30); scene.add(fill);

/* -------------------------------------------------------- TEXTURES ---- */
function canvasTex(w, h, draw, rep) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const g = c.getContext('2d'); draw(g, w, h);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  if (rep) t.repeat.set(rep, rep);
  t.anisotropy = renderer.capabilities.getMaxAnisotropy();
  return t;
}
const noiseOverlay = (g, w, h, amt, alpha) => {
  for (let i = 0; i < amt; i++) {
    g.fillStyle = 'rgba(' + (Math.random() < .5 ? '0,0,0,' : '255,255,255,') + (Math.random() * alpha) + ')';
    const s = Math.random() * 3 + 1;
    g.fillRect(Math.random() * w, Math.random() * h, s, s);
  }
};
const floorTex = canvasTex(512, 512, (g, w, h) => {
  g.fillStyle = '#5d5a53'; g.fillRect(0, 0, w, h);
  noiseOverlay(g, w, h, 9000, 0.22);
  for (let i = 0; i < 26; i++) {
    g.strokeStyle = 'rgba(40,38,35,' + rand(0.06, 0.22) + ')'; g.lineWidth = rand(1, 4);
    g.beginPath(); let x = Math.random() * w, y = Math.random() * h; g.moveTo(x, y);
    for (let k = 0; k < 5; k++) { x += rand(-60, 60); y += rand(-60, 60); g.lineTo(x, y); }
    g.stroke();
  }
  g.strokeStyle = 'rgba(30,28,26,.5)'; g.lineWidth = 3;
  for (let i = 0; i <= 4; i++) {
    g.beginPath(); g.moveTo(0, i * h / 4); g.lineTo(w, i * h / 4); g.stroke();
    g.beginPath(); g.moveTo(i * w / 4, 0); g.lineTo(i * w / 4, h); g.stroke();
  }
}, 14);

const wallTex = canvasTex(256, 256, (g, w, h) => {
  g.fillStyle = '#8a8f8c'; g.fillRect(0, 0, w, h);
  noiseOverlay(g, w, h, 3000, 0.18);
  g.fillStyle = 'rgba(60,64,62,.35)';
  for (let y = 0; y < h; y += 32) g.fillRect(0, y, w, 2);
  for (let i = 0; i < 40; i++) {
    g.fillStyle = 'rgba(120,70,40,' + rand(.05, .25) + ')';
    g.beginPath(); g.arc(Math.random() * w, Math.random() * h, rand(3, 16), 0, 7); g.fill();
  }
}, 3);

const containerTex = (base) => canvasTex(256, 256, (g, w, h) => {
  g.fillStyle = base; g.fillRect(0, 0, w, h);
  for (let x = 0; x < w; x += 16) {
    g.fillStyle = 'rgba(0,0,0,' + (x % 32 === 0 ? .18 : .07) + ')'; g.fillRect(x, 0, 8, h);
  }
  g.fillStyle = 'rgba(255,255,255,.06)'; g.fillRect(0, 0, w, 8);
  g.strokeStyle = 'rgba(0,0,0,.45)'; g.lineWidth = 6; g.strokeRect(3, 3, w - 6, h - 6);
  noiseOverlay(g, w, h, 1400, 0.2);
}, 1);

const crateTex = canvasTex(256, 256, (g, w, h) => {
  g.fillStyle = '#a97c4a'; g.fillRect(0, 0, w, h);
  noiseOverlay(g, w, h, 4000, 0.2);
  g.strokeStyle = 'rgba(70,45,20,.75)'; g.lineWidth = 10; g.strokeRect(5, 5, w - 10, h - 10);
  g.lineWidth = 8; g.beginPath(); g.moveTo(8, 8); g.lineTo(w - 8, h - 8); g.stroke();
  g.beginPath(); g.moveTo(w - 8, 8); g.lineTo(8, h - 8); g.stroke();
}, 1);

/* ----------------------------------------------------------- WORLD ---- */
const colliders = [];   // {minx,maxx,minz,maxz,h}
const hittables = [];   // меши для попаданий
const world = new THREE.Group(); scene.add(world);

const matFloor = new THREE.MeshStandardMaterial({ map: floorTex, roughness: .96, metalness: .02 });
const matWall = new THREE.MeshStandardMaterial({ map: wallTex, roughness: .9, metalness: .08 });
const matMetal = new THREE.MeshStandardMaterial({ color: 0x6b7278, roughness: .55, metalness: .7 });
const matRust = new THREE.MeshStandardMaterial({ color: 0x7a5a44, roughness: .85, metalness: .3 });

const ARENA = 66; // половина стороны

function addCollider(mesh, w, h, d) {
  const p = mesh.position;
  colliders.push({ minx: p.x - w / 2, maxx: p.x + w / 2, minz: p.z - d / 2, maxz: p.z + d / 2, h: (mesh.position.y + h / 2) || h });
}
function addBox(w, h, d, x, y, z, mat, opt) {
  opt = opt || {};
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
  m.position.set(x, y, z);
  if (opt.ry) m.rotation.y = opt.ry;
  m.castShadow = opt.noShadow ? false : true;
  m.receiveShadow = true;
  world.add(m);
  if (!opt.noCollide) {
    const p = m.position;
    const hw = w / 2, hd = d / 2;
    // для повернутых объектов берём увеличенный AABB
    const ex = opt.ry ? Math.abs(Math.cos(opt.ry)) * hw + Math.abs(Math.sin(opt.ry)) * hd : hw;
    const ez = opt.ry ? Math.abs(Math.sin(opt.ry)) * hw + Math.abs(Math.cos(opt.ry)) * hd : hd;
    colliders.push({ minx: p.x - ex, maxx: p.x + ex, minz: p.z - ez, maxz: p.z + ez, h: y + h / 2 });
  }
  if (!opt.noHit) hittables.push(m);
  return m;
}
function addCyl(r, h, x, z, mat, seg) {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, h, seg || 14), mat);
  m.position.set(x, h / 2, z); m.castShadow = true; m.receiveShadow = true;
  world.add(m); hittables.push(m);
  colliders.push({ minx: x - r, maxx: x + r, minz: z - r, maxz: z + r, h: h });
  return m;
}

// земля
const ground = new THREE.Mesh(new THREE.PlaneGeometry(ARENA * 2 + 40, ARENA * 2 + 40), matFloor);
ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);

// периметр
(function walls() {
  const H = 7, T = 2;
  addBox(ARENA * 2, H, T, 0, H / 2, -ARENA, matWall);
  addBox(ARENA * 2, H, T, 0, H / 2, ARENA, matWall);
  addBox(T, H, ARENA * 2, -ARENA, H / 2, 0, matWall);
  addBox(T, H, ARENA * 2, ARENA, H / 2, 0, matWall);
  // ржавые полосы на стенах
  for (let i = 0; i < 18; i++) {
    const side = randi(0, 3), t = rand(-ARENA + 6, ARENA - 6);
    const m = new THREE.Mesh(new THREE.BoxGeometry(rand(2, 6), rand(.3, .8), .2), matRust);
    if (side === 0) m.position.set(t, rand(1, 6), -ARENA + 1.05);
    if (side === 1) m.position.set(t, rand(1, 6), ARENA - 1.05);
    if (side === 2) { m.position.set(-ARENA + 1.05, rand(1, 6), t); m.rotation.y = Math.PI / 2; }
    if (side === 3) { m.position.set(ARENA - 1.05, rand(1, 6), t); m.rotation.y = Math.PI / 2; }
    world.add(m);
  }
})();

// контейнеры
const contCols = ['#2f6b4f', '#8a3b28', '#2c4a75', '#8a6d24', '#5d5f63'];
const contTexes = contCols.map(c => new THREE.MeshStandardMaterial({ map: containerTex(c), roughness: .78, metalness: .35 }));
const spawnPoints = [];
(function containers() {
  const spots = [
    [-24, -18, 0], [-10, -30, 0], [16, -24, 0], [30, -10, Math.PI / 2],
    [-34, 6, Math.PI / 2], [-14, 6, 0], [8, 4, Math.PI / 2], [26, 14, 0],
    [-26, 26, 0], [4, 30, Math.PI / 2], [34, 32, 0], [-40, -34, Math.PI / 2]
  ];
  spots.forEach((s, i) => {
    const m = addBox(12, 2.7, 2.9, s[0], 1.35, s[2] * 0 + 0 + s[1], contTexes[i % contTexes.length], { ry: s[2] });
    m.position.y = 1.35;
    // второй ярус иногда
    if (i % 3 === 0) addBox(12, 2.7, 2.9, s[0], 4.05, s[1], contTexes[(i + 2) % contTexes.length], { ry: s[2] });
    spawnPoints.push(new V3(s[0], 0, s[1]));
  });
})();

// ящики
const crateMat = new THREE.MeshStandardMaterial({ map: crateTex, roughness: .95, metalness: .02 });
(function crates() {
  const clusters = [[-6, -8], [12, -6], [-18, 16], [20, 24], [0, 12], [-30, -4], [30, -30], [-2, -22]];
  clusters.forEach((c, ci) => {
    const n = randi(2, 4);
    for (let i = 0; i < n; i++) {
      const s = rand(1.2, 1.9);
      const x = c[0] + rand(-3, 3), z = c[1] + rand(-3, 3);
      addBox(s, s, s, x, s / 2, z, crateMat, { ry: rand(0, 3) });
      if (Math.random() < .45) addBox(s * .8, s * .8, s * .8, x + rand(-.2, .2), s + s * .4, z + rand(-.2, .2), crateMat, { ry: rand(0, 3) });
    }
  });
})();

// бочки
const barrelMat = new THREE.MeshStandardMaterial({ color: 0xb04a2a, roughness: .6, metalness: .6 });
const barrelMat2 = new THREE.MeshStandardMaterial({ color: 0x4a6b8a, roughness: .6, metalness: .6 });
for (let i = 0; i < 26; i++) {
  const x = rand(-ARENA + 6, ARENA - 6), z = rand(-ARENA + 6, ARENA - 6);
  if (Math.hypot(x, z) < 7) continue;
  addCyl(0.55, rand(1.1, 1.4), x, z, Math.random() < .5 ? barrelMat : barrelMat2);
}

// бетонные блоки (укрытия)
const concMat = new THREE.MeshStandardMaterial({ color: 0x9a9791, roughness: .95 });
for (let i = 0; i < 12; i++) {
  const x = rand(-ARENA + 10, ARENA - 10), z = rand(-ARENA + 10, ARENA - 10);
  if (Math.hypot(x, z) < 9) continue;
  addBox(rand(3, 5), rand(.9, 1.3), rand(1, 1.4), x, .55, z, concMat, { ry: rand(0, Math.PI) });
}

// сторожевая вышка в углу (декор)
(function tower() {
  const TX = -ARENA + 11, TZ = -ARENA + 11;
  addBox(7, 0.5, 7, TX, 5.2, TZ, matMetal);
  [[-3, -3], [3, -3], [-3, 3], [3, 3]].forEach(p => {
    const leg = new THREE.Mesh(new THREE.CylinderGeometry(.2, .2, 5.2, 8), matMetal);
    leg.position.set(TX + p[0], 2.6, TZ + p[1]); leg.castShadow = true; world.add(leg);
    colliders.push({ minx: TX + p[0] - .32, maxx: TX + p[0] + .32, minz: TZ + p[1] - .32, maxz: TZ + p[1] + .32, h: 5.2 });
  });
  const railMat = new THREE.MeshStandardMaterial({ color: 0x5a6066, roughness: .6, metalness: .7 });
  for (let i = 0; i < 4; i++) {
    const a = i * Math.PI / 2;
    const r = new THREE.Mesh(new THREE.BoxGeometry(7, .9, .12), railMat);
    r.position.set(TX + Math.cos(a) * 3.5, 6.0, TZ + Math.sin(a) * 3.5);
    r.rotation.y = a + Math.PI / 2; world.add(r);
  }
})();

// мешки с песком по углам
for (let i = 0; i < 4; i++) {
  const ang = Math.PI / 4 + i * Math.PI / 2;
  for (let k = 0; k < 5; k++) {
    const x = Math.cos(ang) * 20 + rand(-3, 3), z = Math.sin(ang) * 20 + rand(-3, 3);
    addBox(rand(1, 1.5), .7, rand(.8, 1.1), x, .35, z, new THREE.MeshStandardMaterial({ color: 0x8d7f5e, roughness: 1 }), { ry: rand(0, 3) });
  }
}

// расчищаем стартовую площадку: убираем мелкий декор рядом с центром
(function clearSpawn() {
  const keep = [];
  for (const c of colliders) {
    const cx = (c.minx + c.maxx) / 2, cz = (c.minz + c.maxz) / 2;
    if (Math.hypot(cx, cz) > 9) keep.push(c);
  }
  colliders.length = 0; colliders.push.apply(colliders, keep);
})();

/* ----------------------------------------------------------- PLAYER ---- */
const player = {
  pos: new V3(0, 0, 0),
  yaw: 0, pitch: 0,
  vel: new V3(0, 0, 0),
  height: 1.7, crouch: false, crouchT: 0,
  onGround: true, jumpVel: 0,
  hp: 100, maxHp: 100,
  stamina: 1, sprinting: false,
  alive: true,
  bobT: 0, bob: 0,
  ads: false, adsT: 0, jumpY: 0,
  recoil: 0, recoilPitch: 0, recoilYaw: 0,
  flash: 0
};
const PLAYER_R = 0.42;

function collidesAt(x, z, r) {
  for (let i = 0; i < colliders.length; i++) {
    const c = colliders[i];
    if (x + r > c.minx && x - r < c.maxx && z + r > c.minz && z - r < c.maxz) return c;
  }
  return null;
}
function resolveMove(pos, dx, dz, r) {
  // пробуем по осям отдельно — плавное скольжение вдоль стен
  if (!collidesAt(pos.x + dx, pos.z, r)) pos.x += dx;
  if (!collidesAt(pos.x, pos.z + dz, r)) pos.z += dz;
  // жёсткий вылет за пределы арены
  pos.x = clamp(pos.x, -ARENA + 2.2, ARENA - 2.2);
  pos.z = clamp(pos.z, -ARENA + 2.2, ARENA - 2.2);
}

/* ---------------------------------------------------------- WEAPONS ---- */
const WEAPONS = {
  ak47: {
    id: 'ak47', name: 'AK-47', type: 'rifle', dmg: 33, rpm: 620, mag: 30, reserve: 240,
    spread: 0.013, adsSpread: 0.0035, recoil: 0.011, auto: true, reloadTime: 2.1,
    zoom: 1.15, sound: 'rifle', wcol: 0x3a2f26, metalCol: 0x2a2a2a, scale: 1
  },
  m4: {
    id: 'm4', name: 'M4 CARBINE', type: 'rifle', dmg: 26, rpm: 800, mag: 30, reserve: 300,
    spread: 0.010, adsSpread: 0.0028, recoil: 0.008, auto: true, reloadTime: 1.9,
    zoom: 1.15, sound: 'rifle', wcol: 0x2b2f2c, metalCol: 0x1e2224, scale: 1
  },
  mp5: {
    id: 'mp5', name: 'MP5', type: 'smg', dmg: 21, rpm: 880, mag: 32, reserve: 320,
    spread: 0.016, adsSpread: 0.006, recoil: 0.006, auto: true, reloadTime: 1.6,
    zoom: 1.1, sound: 'rifle', wcol: 0x22252a, metalCol: 0x191c1f, scale: 0.85
  },
  shotgun: {
    id: 'shotgun', name: 'ОБРЕЗ 12К', type: 'shotgun', dmg: 15, pellets: 8, rpm: 90, mag: 8, reserve: 64,
    spread: 0.055, adsSpread: 0.035, recoil: 0.030, auto: false, reloadTime: 2.6,
    zoom: 1.0, sound: 'shotgun', wcol: 0x4a3524, metalCol: 0x24242a, scale: 1.05
  },
  sniper: {
    id: 'sniper', name: 'AWP', type: 'sniper', dmg: 135, rpm: 50, mag: 5, reserve: 40,
    spread: 0.0015, adsSpread: 0.0002, recoil: 0.045, auto: false, reloadTime: 3.2,
    zoom: 4.0, sound: 'sniper', wcol: 0x1f2a22, metalCol: 0x15181a, scale: 1.1
  },
  pistol: {
    id: 'pistol', name: 'M9', type: 'pistol', dmg: 30, rpm: 420, mag: 15, reserve: 120,
    spread: 0.012, adsSpread: 0.004, recoil: 0.013, auto: false, reloadTime: 1.4,
    zoom: 1.05, sound: 'pistol', wcol: 0x25272b, metalCol: 0x1b1d20, scale: 0.8
  }
};

/* ---- модель оружия (viewmodel) ---- */
function buildGunModel(def) {
  const g = new THREE.Group();
  const body = new THREE.MeshStandardMaterial({ color: new THREE.Color(def.wcol).lerp(new THREE.Color(0xffffff), 0.18), roughness: .55, metalness: .5 });
  const metal = new THREE.MeshStandardMaterial({ color: new THREE.Color(def.metalCol).lerp(new THREE.Color(0xffffff), 0.22), roughness: .35, metalness: .85 });
  const wood = new THREE.MeshStandardMaterial({ color: 0x8a4d20, roughness: .7, metalness: .05 });
  const s = def.scale;

  const add = (w, h, d, x, y, z, mat, ry, rx) => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(w * s, h * s, d * s), mat || metal);
    m.position.set(x * s, y * s, z * s);
    if (ry) m.rotation.y = ry;
    if (rx) m.rotation.x = rx;
    g.add(m); return m;
  };
  // Модели Ultimate Guns Pack, Quaternius (CC0).
  const barrelLen = def.type === 'sniper' ? 0.62 : def.type === 'smg' ? 0.24 : def.type === 'shotgun' ? 0.36 : 0.46;
  const parts = GUN_ASSETS[def.id];
  if (parts) {
    let lo=Infinity, hi=-Infinity;
    for (const part of parts) for (const v of part.v) { lo=Math.min(lo,v[0]); hi=Math.max(hi,v[0]); }
    const factor = (def.type === 'pistol' ? 0.44 : 0.84) * s / (hi-lo);
    for (const part of parts) {
      const vertices=[], colors=[];
      for (const face of part.f) {
        const c=part.colors[face[3]] || [0.1,0.1,0.1];
        for (let j=0;j<3;j++) { const v=part.v[face[j]];
          vertices.push(-v[1]*factor, v[2]*factor-0.04, -(v[0]-(lo+hi)*0.5)*factor-0.12);
          colors.push(Math.min(1,c[0]*1.5+0.04),Math.min(1,c[1]*1.5+0.04),Math.min(1,c[2]*1.5+0.04));
        }
      }
      const geo=new THREE.BufferGeometry();
      geo.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));
      geo.setAttribute('color',new THREE.Float32BufferAttribute(colors,3)); geo.computeVertexNormals();
      g.add(new THREE.Mesh(geo,new THREE.MeshStandardMaterial({vertexColors:true, roughness:.65,metalness:.25,side:THREE.DoubleSide})));
    }
  }
  // руки
  const glove = new THREE.MeshStandardMaterial({ color: 0x22242a, roughness: .85, metalness: .1 });
  const sleeve = new THREE.MeshStandardMaterial({ color: 0x5c6b4a, roughness: .95 });
  const armR = new THREE.Mesh(new THREE.BoxGeometry(0.075 * s, 0.075 * s, 0.3 * s), sleeve);
  armR.position.set(0.055 * s, -0.14 * s, 0.24 * s); armR.rotation.x = -0.5; armR.rotation.z = 0.25; g.add(armR);
  const hR = new THREE.Mesh(new THREE.BoxGeometry(0.08 * s, 0.09 * s, 0.1 * s), glove);
  hR.position.set(0.01 * s, -0.11 * s, 0.16 * s); g.add(hR);
  const armL = new THREE.Mesh(new THREE.BoxGeometry(0.06 * s, 0.06 * s, 0.3 * s), sleeve);
  armL.position.set(-0.09 * s, -0.15 * s, -0.1 * s); armL.rotation.y = -0.7; armL.rotation.x = -0.15; g.add(armL);
  const hL = new THREE.Mesh(new THREE.BoxGeometry(0.09 * s, 0.075 * s, 0.11 * s), glove);
  hL.position.set(-0.055 * s, -0.06 * s, -0.3 * s); g.add(hL);

  // дульный огонь
  const flashGeo = new THREE.PlaneGeometry(0.28, 0.28);
  const flashTex = canvasTex(64, 64, (gg, w, h) => {
    const grd = gg.createRadialGradient(32, 32, 2, 32, 32, 30);
    grd.addColorStop(0, 'rgba(255,255,230,1)'); grd.addColorStop(.35, 'rgba(255,190,80,.9)'); grd.addColorStop(1, 'rgba(255,120,0,0)');
    gg.fillStyle = grd; gg.fillRect(0, 0, w, h);
  });
  const flash = new THREE.Mesh(flashGeo, new THREE.MeshBasicMaterial({ map: flashTex, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false }));
  flash.position.set(0, 0.012 * s, -0.24 - barrelLen - 0.03); flash.visible = false; g.add(flash);

  g.userData.flash = flash;
  g.userData.muzzle = new V3(0, 0.012 * s, -0.26 - barrelLen);
  return g;
}

/* -------------------------------------------------------- VIEWMODEL ---- */
const viewRoot = new THREE.Group(); gunScene.add(viewRoot);
const gunHolder = new THREE.Group(); gunHolder.scale.setScalar(0.78); viewRoot.add(gunHolder);
const gunTilt = new THREE.Group(); gunTilt.rotation.y = 0.055; gunTilt.rotation.x = 0.02; gunHolder.add(gunTilt);

const loadout = { primary: 'ak47', list: [] };
const WSTATE = {}; // патроны по оружию

function initLoadout(primaryId, secondaryId) {
  while (gunTilt.children.length) gunTilt.remove(gunTilt.children[0]);
  loadout.list = [primaryId, secondaryId || 'pistol'];
  loadout.index = 0;
  loadout.models = {};
  loadout.list.forEach(id => {
    const m = buildGunModel(WEAPONS[id]);
    m.visible = false; gunTilt.add(m);
    loadout.models[id] = m;
    if (!WSTATE[id]) WSTATE[id] = { mag: WEAPONS[id].mag, reserve: WEAPONS[id].reserve };
    else { WSTATE[id].mag = WEAPONS[id].mag; WSTATE[id].reserve = WEAPONS[id].reserve; }
  });
  selectWeapon(0);
  renderWeaponSlots();
}
function curWeapon() { return WEAPONS[loadout.list[loadout.index]]; }
function curState() { return WSTATE[curWeapon().id]; }
function selectWeapon(i) {
  if (i < 0 || i >= loadout.list.length) return;
  loadout.index = i;
  Object.keys(loadout.models).forEach(id => loadout.models[id].visible = false);
  loadout.models[loadout.list[i]].visible = true;
  loadout.switchT = 0.32;
  reloading = 0; reloadTotal = 0;
  updateAmmoHud();
  renderWeaponSlots();
}
function renderWeaponSlots() {
  const el = document.getElementById('wsel');
  el.innerHTML = loadout.list.map((id, i) =>
    '<div class="' + (i === loadout.index ? 'on' : '') + '">' + (i + 1) + '</div>').join('');
  document.getElementById('wname').textContent = curWeapon().name;
}

/* ---------------------------------------------------------- SHOOTING ---- */
let reloading = 0, reloadTotal = 0, fireCooldown = 0, triggerHeld = false, shotQueued = false;
const raycaster = new THREE.Raycaster();
raycaster.far = 300;
const tracerPool = [];
const TRACER_N = 40;

function makeTracer() {
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(6), 3));
  const mat = new THREE.LineBasicMaterial({ color: 0xffe8a0, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false });
  const line = new THREE.Line(geo, mat); line.frustumCulled = false; scene.add(line);
  return { line, life: 0 };
}
for (let i = 0; i < TRACER_N; i++) tracerPool.push(makeTracer());
let tracerIdx = 0;
function spawnTracer(from, to, color, op) {
  const t = tracerPool[tracerIdx++ % TRACER_N];
  const p = t.line.geometry.attributes.position;
  p.setXYZ(0, from.x, from.y, from.z);
  p.setXYZ(1, to.x, to.y, to.z);
  p.needsUpdate = true;
  t.line.material.color.setHex(color || 0xffe8a0);
  t.line.material.opacity = op === undefined ? 0.9 : op;
  t.life = 0.075;
  t.line.visible = true;
}

// искры / кровь
const PART_N = 220;
const partGeo = new THREE.BufferGeometry();
const partPos = new Float32Array(PART_N * 3);
const partCol = new Float32Array(PART_N * 3);
partGeo.setAttribute('position', new THREE.BufferAttribute(partPos, 3));
partGeo.setAttribute('color', new THREE.BufferAttribute(partCol, 3));
const partMat = new THREE.PointsMaterial({ size: 0.11, vertexColors: true, transparent: true, opacity: .95, depthWrite: false });
const partPoints = new THREE.Points(partGeo, partMat); partPoints.frustumCulled = false; scene.add(partPoints);
const parts = [];
for (let i = 0; i < PART_N; i++) parts.push({ life: 0, vx: 0, vy: 0, vz: 0, x: 0, y: -100, z: 0 });
let partIdx = 0;
function burst(pos, color, n, spd) {
  for (let i = 0; i < n; i++) {
    const p = parts[partIdx = (partIdx + 1) % PART_N];
    p.x = pos.x; p.y = pos.y; p.z = pos.z;
    p.vx = rand(-1, 1) * (spd || 2.4); p.vy = rand(.2, 1.6) * (spd || 2.4); p.vz = rand(-1, 1) * (spd || 2.4);
    p.life = rand(.25, .7);
    partCol[(partIdx) * 3] = color.r; partCol[(partIdx) * 3 + 1] = color.g; partCol[(partIdx) * 3 + 2] = color.b;
  }
}
function updateParticles(dt) {
  for (let i = 0; i < PART_N; i++) {
    const p = parts[i];
    if (p.life > 0) {
      p.life -= dt;
      p.vy -= 9 * dt;
      p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt;
      if (p.y < 0.02) { p.y = 0.02; p.vy *= -0.25; p.vx *= .6; p.vz *= .6; }
      partPos[i * 3] = p.x; partPos[i * 3 + 1] = p.y; partPos[i * 3 + 2] = p.z;
    } else { partPos[i * 3 + 1] = -100; }
  }
  partGeo.attributes.position.needsUpdate = true;
  partGeo.attributes.color.needsUpdate = true;
}

function muzzleWorldPos() {
  const m = loadout.models[loadout.list[loadout.index]];
  const v = m.userData.muzzle.clone();
  m.localToWorld(v);
  // из сцены оружия в мир: точка перед камерой
  const camDir = new V3(0, 0, -1).applyQuaternion(camera.quaternion);
  const right = new V3(1, 0, 0).applyQuaternion(camera.quaternion);
  const up = new V3(0, 1, 0).applyQuaternion(camera.quaternion);
  return camera.position.clone()
    .add(camDir.multiplyScalar(0.55))
    .add(right.multiplyScalar(0.14))
    .add(up.multiplyScalar(-0.1));
}

function currentSpread() {
  const w = curWeapon();
  let s = player.ads ? w.adsSpread : w.spread;
  const speed = Math.hypot(player.vel.x, player.vel.z);
  s += speed * 0.0022;
  if (!player.onGround) s += 0.02;
  if (player.crouch) s *= 0.65;
  return s;
}

function tryFire() {
  if (!player.alive || paused || gameState !== 'play') return;
  const w = curWeapon(); const st = curState();
  if (fireCooldown > 0 || reloading > 0 || loadout.switchT > 0) return;
  if (st.mag <= 0) {
    AudioSys.empty();
    if (st.reserve > 0) startReload();
    fireCooldown = 0.25;
    return;
  }
  st.mag--;
  fireCooldown = 60 / w.rpm;
  AudioSys.shot(w.sound);

  // отдача
  player.recoilPitch += w.recoil * rand(0.75, 1.25);
  player.recoilYaw += w.recoil * rand(-0.5, 0.5);
  player.flash = 1;
  const mdl = loadout.models[w.id];
  mdl.position.z += 0.055;
  if (mdl.userData.flash) {
    mdl.userData.flash.visible = true;
    mdl.userData.flash.rotation.z = rand(0, 6.28);
    mdl.userData.flash.scale.setScalar(rand(.8, 1.5));
    mdl.userData.flashTimer = 0.045;
  }
  muzzleLight.intensity = 2.6; muzzleLight.position.copy(mdl.userData.muzzle);

  const origin = camera.position.clone();
  const baseDir = new V3(0, 0, -1).applyQuaternion(camera.quaternion);
  const muzzle = muzzleWorldPos();
  const pellets = w.pellets || 1;

  for (let p = 0; p < pellets; p++) {
    const spread = currentSpread();
    const dir = baseDir.clone();
    dir.x += rand(-spread, spread) * (1 + Math.abs(baseDir.x));
    dir.y += rand(-spread, spread);
    dir.z += rand(-spread, spread) * (1 + Math.abs(baseDir.z));
    dir.normalize();

    raycaster.set(origin, dir);
    const targets = hittables.concat(enemyHitMeshes);
    const hits = raycaster.intersectObjects(targets, false);
    let end = origin.clone().add(dir.clone().multiplyScalar(180));
    let hitEnemy = null;
    if (hits.length) {
      const h = hits[0];
      end = h.point.clone();
      if (h.object.userData.enemy) hitEnemy = h.object.userData;
      else {
        // искры о поверхность
        burst(h.point, new THREE.Color(0xffd08a), 5, 2.2);
        spawnTracer(muzzle, h.point, 0xffe8a0, .85);
      }
    }
    if (hitEnemy) {
      const isHead = hitEnemy.part === 'head';
      const dmg = w.dmg * (isHead ? 2.6 : 1) * (w.type === 'sniper' && isHead ? 1.2 : 1);
      damageEnemy(hitEnemy.enemy, dmg, isHead, h => h.point);
      burst(end, new THREE.Color(0xb0141a), isHead ? 16 : 9, 3);
      spawnTracer(muzzle, end, 0xffd0a0, .9);
    }
    if (!hits.length) spawnTracer(muzzle, end, 0xffe8a0, .6);
  }
  updateAmmoHud();
  if (st.mag === 0 && st.reserve > 0) setTimeout(() => { if (player.alive) startReload(); }, 220);
}

function startReload() {
  const w = curWeapon(); const st = curState();
  if (reloading > 0 || st.mag >= w.mag || st.reserve <= 0) return;
  reloading = w.reloadTime; reloadTotal = w.reloadTime;
  AudioSys.reload();
  document.getElementById('reloading').classList.add('on');
}
function finishReload() {
  const w = curWeapon(); const st = curState();
  const need = w.mag - st.mag;
  const give = Math.min(need, st.reserve);
  st.mag += give; st.reserve -= give;
  document.getElementById('reloading').classList.remove('on');
  updateAmmoHud();
}
function updateAmmoHud() {
  const w = curWeapon(); const st = curState();
  document.getElementById('ammo').textContent = st.mag;
  document.getElementById('reserve').textContent = '/ ' + st.reserve;
  document.getElementById('ammo').style.color = st.mag === 0 ? '#ff3b30' : '';
  document.getElementById('wname').textContent = w.name;
}

/* ----------------------------------------------------------- ENEMIES ---- */
const enemyHitMeshes = [];
const enemies = [];
let enemyGroupRoot = new THREE.Group(); scene.add(enemyGroupRoot);

const ENEMY_SKINS = [
  { body: 0x6b6a4a, pants: 0x4c4b34, vest: 0x3f4230 },
  { body: 0x5a5f66, pants: 0x3d4147, vest: 0x2e3238 },
  { body: 0x6e5240, pants: 0x4a382c, vest: 0x3a2c22 }
];

function barSprite(color) {
  const tex = canvasTex(4, 4, (g) => { g.fillStyle = color; g.fillRect(0, 0, 4, 4); });
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, depthTest: true }));
  return sp;
}

function makeEnemy(pos, hp, dmg, speed) {
  const g = new THREE.Group();
  const skin = choose(ENEMY_SKINS);
  const mBody = new THREE.MeshStandardMaterial({ color: skin.body, roughness: .92 });
  const mPants = new THREE.MeshStandardMaterial({ color: skin.pants, roughness: .95 });
  const mVest = new THREE.MeshStandardMaterial({ color: skin.vest, roughness: .85 });
  const mSkin = new THREE.MeshStandardMaterial({ color: 0xb98a68, roughness: .85 });
  const mGun = new THREE.MeshStandardMaterial({ color: 0x1c1d20, roughness: .5, metalness: .7 });
  const mHelm = new THREE.MeshStandardMaterial({ color: 0x3a4030, roughness: .8 });

  // торс
  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.58, 0.66, 0.32), mBody);
  torso.position.y = 1.18; torso.castShadow = true; g.add(torso);
  const vest = new THREE.Mesh(new THREE.BoxGeometry(0.62, 0.44, 0.37), mVest);
  vest.position.y = 1.2; vest.castShadow = true; g.add(vest);

  // голова
  const head = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.28, 0.26), mSkin);
  head.position.y = 1.64; head.castShadow = true; g.add(head);
  const helmet = new THREE.Mesh(new THREE.SphereGeometry(0.19, 10, 8, 0, Math.PI * 2, 0, Math.PI / 1.8), mHelm);
  helmet.position.y = 1.69; helmet.castShadow = true; g.add(helmet);

  // руки
  const armL = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.5, 0.15), mBody);
  armL.position.set(-0.36, 1.15, -0.06); armL.rotation.x = -0.9; armL.castShadow = true; g.add(armL);
  const armR = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.5, 0.15), mBody);
  armR.position.set(0.36, 1.15, -0.06); armR.rotation.x = -1.0; armR.castShadow = true; g.add(armR);
  // оружие
  const gun = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.12, 0.72), mGun);
  gun.position.set(0.22, 1.24, -0.42); gun.castShadow = true; g.add(gun);
  const gunTip = new THREE.Object3D(); gunTip.position.set(0.22, 1.24, -0.8); g.add(gunTip);

  // ноги
  const legL = new THREE.Group(); legL.position.set(-0.15, 0.85, 0);
  const legLM = new THREE.Mesh(new THREE.BoxGeometry(0.19, 0.85, 0.21), mPants);
  legLM.position.y = -0.42; legLM.castShadow = true; legL.add(legLM); g.add(legL);
  const legR = new THREE.Group(); legR.position.set(0.15, 0.85, 0);
  const legRM = new THREE.Mesh(new THREE.BoxGeometry(0.19, 0.85, 0.21), mPants);
  legRM.position.y = -0.42; legRM.castShadow = true; legR.add(legRM); g.add(legR);

  // полоска здоровья
  const hpBg = new THREE.Sprite(new THREE.SpriteMaterial({ color: 0x000000, depthTest: true, depthWrite: false, transparent: true, opacity: .6 }));
  hpBg.scale.set(0.86, 0.1, 1); hpBg.position.set(0, 2.05, 0); hpBg.center.set(0, 0.5);
  hpBg.position.x = -0.4; g.add(hpBg); hpBg.visible = false;
  const hpFill = new THREE.Sprite(new THREE.SpriteMaterial({ color: 0x54d66b, depthTest: true, depthWrite: false }));
  hpFill.scale.set(0.8, 0.065, 1); hpFill.position.set(-0.4, 2.05, 0.001); hpFill.center.set(0, 0.5); g.add(hpFill); hpFill.visible = false;

  g.position.copy(pos);
  enemyGroupRoot.add(g);

  const e = {
    root: g, head, torso, vest, gun, gunTip, legL, legR, hpFill, hpBg,
    losT: 0, seen: false,
    hp: hp, maxHp: hp, dmg, speed, alive: true,
    state: 'advance', fireT: rand(0.5, 2.2), walkT: 0, dieT: 0, flashT: 0,
    strafeDir: Math.random() < .5 ? 1 : -1, strafeT: rand(1, 3), yaw: 0
  };
  // хитбоксы
  head.userData.enemy = e; head.userData.part = 'head';
  torso.userData.enemy = e; torso.userData.part = 'body';
  vest.userData.enemy = e; vest.userData.part = 'body';
  for (let i = 0; i < legL.children.length; i++) { legL.children[i].userData.enemy = e; legL.children[i].userData.part = 'body'; }
  for (let i = 0; i < legR.children.length; i++) { legR.children[i].userData.enemy = e; legR.children[i].userData.part = 'body'; }
  armL.userData.enemy = e; armL.userData.part = 'body';
  armR.userData.enemy = e; armR.userData.part = 'body';
  enemyHitMeshes.push(head, torso, vest, armL, armR, legL.children[0], legR.children[0]);

  enemies.push(e);
  return e;
}

function damageEnemy(e, dmg, headshot, pointFn) {
  if (!e.alive) return;
  e.hp -= dmg;
  e.flashT = 0.09;
  e.hpFill.scale.x = Math.max(0, 0.8 * (e.hp / e.maxHp));
  e.hpFill.material.color.setHex(e.hp / e.maxHp > .5 ? 0x54d66b : e.hp / e.maxHp > .25 ? 0xffb020 : 0xff3b30);
  if (headshot) AudioSys.head(); else AudioSys.hit();
  showHitmark(headshot);

  if (e.hp <= 0) killEnemy(e, headshot);
}

function killEnemy(e, headshot) {
  e.alive = false; e.state = 'dead'; e.dieT = 0;
  stats.kills++; if (headshot) stats.headshots++;
  const pts = (headshot ? 150 : 100) + (wave * 10);
  stats.score += pts;
  AudioSys.kill();
  popup((headshot ? '🎯 ХЕДШОТ ' : 'УБИТ ') + '+' + pts, headshot, true);
  // падаем
  e.fallDir = 1;
  setTimeout(() => {
    const idx = enemyHitMeshes.indexOf(e.head);
    [e.head, e.torso, e.vest].forEach(m => { const i = enemyHitMeshes.indexOf(m); if (i >= 0) enemyHitMeshes.splice(i, 1); });
  }, 10);
}

function updateEnemies(dt) {
  for (let i = enemies.length - 1; i >= 0; i--) {
    const e = enemies[i];
    const g = e.root;
    if (!e.alive) {
      e.dieT += dt;
      // заваливание
      g.rotation.z = lerp(g.rotation.z, Math.PI / 2 * 0.92, Math.min(1, dt * 6));
      g.position.y = lerp(g.position.y, -0.05, Math.min(1, dt * 4));
      if (e.dieT > 3.2) {
        g.position.y -= dt * 0.9;
        if (e.dieT > 4.6) { enemyGroupRoot.remove(g); enemies.splice(i, 1); }
      }
      continue;
    }

    // вспышка при попадании
    if (e.flashT > 0) {
      e.flashT -= dt;
      e.torso.material.emissive.setRGB(0.8, 0.05, 0.05);
    } else if (e.wasFlash) {
      e.torso.material.emissive.setRGB(0, 0, 0);
    }
    e.wasFlash = e.flashT > 0;

    const toP = new V3(player.pos.x - g.position.x, 0, player.pos.z - g.position.z);
    const dist = toP.length();
    toP.normalize();
    const targetYaw = Math.atan2(-toP.x, -toP.z);
    // плавный поворот
    let dy = targetYaw - g.rotation.y;
    while (dy > Math.PI) dy -= Math.PI * 2;
    while (dy < -Math.PI) dy += Math.PI * 2;
    g.rotation.y += clamp(dy, -5 * dt, 5 * dt);

    // движение
    let moveX = 0, moveZ = 0;
    if (!player.alive) { /* стоим */ }
    else if (dist > 14) { moveX = toP.x; moveZ = toP.z; }
    else if (dist < 6) { moveX = -toP.x * .7; moveZ = -toP.z * .7; }
    else {
      e.strafeT -= dt;
      if (e.strafeT <= 0) { e.strafeT = rand(1.2, 2.8); e.strafeDir *= -1; }
      moveX = -toP.z * e.strafeDir * .8;
      moveZ = toP.x * e.strafeDir * .8;
    }
    // обход препятствий
    const spd = e.speed * (dist > 14 ? 1 : 0.55);
    if (moveX || moveZ) {
      const len = Math.hypot(moveX, moveZ) || 1;
      moveX /= len; moveZ /= len;
      let moved = false;
      const angles = [0, 0.6, -0.6, 1.2, -1.2, 2.0, -2.0];
      for (let a = 0; a < angles.length; a++) {
        const ca = Math.cos(angles[a]), sa = Math.sin(angles[a]);
        const nx = g.position.x + (moveX * ca - moveZ * sa) * spd * dt;
        const nz = g.position.z + (moveX * sa + moveZ * ca) * spd * dt;
        if (!collidesAt(nx, nz, 0.45) && Math.abs(nx) < ARENA - 2.5 && Math.abs(nz) < ARENA - 2.5) {
          g.position.x = nx; g.position.z = nz; moved = true; break;
        }
      }
      if (!moved) { /* застрял — меняем стрейф */ e.strafeDir *= -1; }

      // анимация ног
      e.walkT += dt * spd * 2.6;
      const sw = Math.sin(e.walkT) * 0.55;
      e.legL.rotation.x = sw; e.legR.rotation.x = -sw;
      g.position.y = Math.abs(Math.sin(e.walkT * 2)) * 0.035;
    }

    // видимость для игрока (без wallhack): луч не проходит сквозь укрытия
    e.losT -= dt;
    if (e.losT <= 0) {
      e.losT = 0.12;
      e.seen = player.alive && dist < 60 && hasLOS(player.pos, g.position);
    }
    const showBar = e.seen && e.hp < e.maxHp - 0.5;
    if (e.hpBg.visible !== showBar) { e.hpBg.visible = showBar; e.hpFill.visible = showBar; }

    // стрельба
    if (player.alive && dist < 42) {
      e.fireT -= dt;
      if (e.fireT <= 0) {
        e.fireT = rand(0.7, 1.9) / (1 + wave * 0.06);
        if (hasLOS(g.position, player.pos)) {
          enemyShoot(e, dist);
        }
      }
    }
  }
}

function hasLOS(from, to) {
  const ax = from.x, az = from.z, bx = to.x, bz = to.z;
  for (let i = 0; i < colliders.length; i++) {
    const c = colliders[i];
    if (c.h < 1.4) continue;
    // slab test в 2D
    let t0 = 0, t1 = 1;
    const dx = bx - ax, dz = bz - az;
    if (Math.abs(dx) < 1e-6) { if (ax < c.minx || ax > c.maxx) continue; }
    else {
      let ta = (c.minx - ax) / dx, tb = (c.maxx - ax) / dx;
      if (ta > tb) { const q = ta; ta = tb; tb = q; }
      t0 = Math.max(t0, ta); t1 = Math.min(t1, tb);
    }
    if (Math.abs(dz) < 1e-6) { if (az < c.minz || az > c.maxz) continue; }
    else {
      let ta = (c.minz - az) / dz, tb = (c.maxz - az) / dz;
      if (ta > tb) { const q = ta; ta = tb; tb = q; }
      t0 = Math.max(t0, ta); t1 = Math.min(t1, tb);
    }
    if (t0 <= t1 && t1 > 0.02 && t0 < 0.98) return false;
  }
  return true;
}

function enemyShoot(e, dist) {
  const origin = new V3(); e.gunTip.getWorldPosition(origin);
  const aim = new V3(player.pos.x, player.height * 0.85 - (player.crouch ? 0.5 : 0), player.pos.z);
  const spreadBase = 0.06 + Math.max(0, dist - 12) * 0.004;
  const missChance = clamp(0.10 + dist * 0.012 + (player.sprinting ? 0.14 : 0) + (player.crouch ? -0.05 : 0), 0.05, 0.72);
  const willHit = Math.random() > missChance;
  const dir = aim.clone().sub(origin).normalize();
  if (!willHit) {
    dir.x += rand(-1, 1) * spreadBase * 3;
    dir.y += rand(-.4, 1) * spreadBase * 2;
    dir.normalize();
  }
  const end = origin.clone().add(dir.multiplyScalar(80));
  spawnTracer(origin, end, 0xffbb55, .7);
  AudioSys.enemyShot();
  muzzleEnemyFlash(origin);
  if (willHit) {
    const dmg = e.dmg * rand(.8, 1.15);
    damagePlayer(dmg, origin);
  }
}
function muzzleEnemyFlash(pos) {
  burst(pos, new THREE.Color(0xffcc66), 3, 1.6);
}

function damagePlayer(dmg, fromPos) {
  if (!player.alive || godMode) return;
  player.hp -= dmg;
  AudioSys.hurt();
  const vig = document.getElementById('vig');
  vig.style.boxShadow = 'inset 0 0 160px 40px rgba(255,20,20,' + clamp(0.55 + dmg / 60, .2, .85) + ')';
  setTimeout(() => vig.style.boxShadow = 'inset 0 0 140px 30px rgba(255,0,0,0)', 160);
  document.getElementById('dmgdir').style.opacity = '0.9';
  setTimeout(() => document.getElementById('dmgdir').style.opacity = '0', 120);
  if (player.hp <= 0) { player.hp = 0; die(); }
  updateHealthHud();
}
function updateHealthHud() {
  document.getElementById('hpnum').textContent = Math.max(0, Math.round(player.hp));
  document.getElementById('hpfill').style.transform = 'scaleX(' + clamp(player.hp / player.maxHp, 0, 1) + ')';
}

/* ------------------------------------------------------------ WAVES ---- */
let wave = 0, waveState = 'idle', waveTimer = 0, toSpawn = 0, spawnTimer = 0;
const stats = { score: 0, kills: 0, headshots: 0 };
let gameState = 'menu', paused = false, godMode = false;

function startWave() {
  wave++;
  toSpawn = 4 + Math.floor(wave * 2.2);
  spawnTimer = 0.4;
  waveState = 'spawning';
  AudioSys.wave();
  feed('ВОЛНА ' + wave + ' — ПОШЛИ ГОСТИ 🌹', 'wave');
  document.getElementById('wave').textContent = wave;
  if (wave > 1) {
    player.hp = Math.min(player.maxHp, player.hp + 35);
    updateHealthHud();
    // пополняем запас
    loadout.list.forEach(id => { WSTATE[id].reserve = WEAPONS[id].reserve; });
    updateAmmoHud();
  }
  if (wave === 1) feed('Держим склад, братик!', 'wave');
}

function spawnOne() {
  const alive = enemies.filter(e => e.alive).length;
  if (alive >= 6 + Math.min(8, wave)) return false;
  // точка подальше от игрока
  let best = null, bestD = -1;
  for (let i = 0; i < 12; i++) {
    const p = new V3(rand(-ARENA + 8, ARENA - 8), 0, rand(-ARENA + 8, ARENA - 8));
    if (collidesAt(p.x, p.z, 1)) continue;
    const d = p.distanceTo(player.pos);
    if (d > 20 && d > bestD) { bestD = d; best = p; }
  }
  if (!best) best = new V3(rand(-20, 20), 0, -25);
  const hp = 100 + (wave - 1) * 18;
  const dmg = 6 + wave * 1.1;
  const speed = Math.min(4.6, 2.1 + wave * 0.12);
  makeEnemy(best, hp, dmg, speed);
  // эффект появления
  burst(new V3(best.x, 1, best.z), new THREE.Color(0x88aaff), 10, 2);
  return true;
}

function updateWaves(dt) {
  if (waveState === 'spawning') {
    spawnTimer -= dt;
    if (spawnTimer <= 0 && toSpawn > 0) {
      if (spawnOne()) toSpawn--;
      spawnTimer = rand(0.35, 0.9) - Math.min(0.25, wave * 0.02);
    }
    if (toSpawn <= 0) waveState = 'fighting';
  } else if (waveState === 'fighting') {
    const alive = enemies.filter(e => e.alive).length;
    if (alive === 0) {
      waveState = 'break'; waveTimer = 5;
      stats.score += 250 + wave * 60;
      feed('ВОЛНА ' + wave + ' ЗАЧИЩЕНА! +' + (250 + wave * 60), 'wave');
      player.hp = Math.min(player.maxHp, player.hp + 20);
      updateHealthHud();
    }
  } else if (waveState === 'break') {
    waveTimer -= dt;
    document.getElementById('hint').textContent = 'Следующая волна через ' + Math.ceil(waveTimer) + '...';
    document.getElementById('hint').style.opacity = '.8';
    if (waveTimer <= 0) { document.getElementById('hint').style.opacity = '0'; startWave(); }
  }
  document.getElementById('enemiesLeft').textContent = (enemies.filter(e => e.alive).length + Math.max(0, toSpawn));
}

/* ------------------------------------------------------------ EFFECTS ---- */
const hitmarkEl = document.getElementById('hitmark');
let hitT = 0;
function showHitmark(head) {
  hitT = 0.16;
  hitmarkEl.style.opacity = '1';
  hitmarkEl.style.transform = 'translate(-50%,-50%) rotate(45deg) scale(' + (head ? 1.5 : 1) + ')';
  hitmarkEl.querySelectorAll('i').forEach(i => i.style.background = head ? '#ffd257' : '#ffffff');
}
const feedEl = document.getElementById('feed');
function feed(text, cls) {
  const d = document.createElement('div');
  d.textContent = text; if (cls) d.className = cls;
  feedEl.appendChild(d);
  setTimeout(() => { d.style.transition = 'opacity .4s'; d.style.opacity = '0'; setTimeout(() => d.remove(), 420); }, 2200);
  while (feedEl.children.length > 5) feedEl.removeChild(feedEl.firstChild);
}
function popup(text, isHead, isKill) { if (!isKill) return; feed(text, isHead ? 'hs' : ''); }

/* -------------------------------------------------------------- CAMERA ---- */
const tmpDir = new V3();
function updateCamera(dt) {
  const eye = player.height - (player.crouch ? 0.5 : 0) + player.bob;
  camera.position.set(player.pos.x, eye + player.jumpY, player.pos.z);
  camera.rotation.set(player.pitch + player.recoilPitch, player.yaw + player.recoilYaw, 0);
  // затухание отдачи
  player.recoilPitch = lerp(player.recoilPitch, 0, Math.min(1, dt * 9));
  player.recoilYaw = lerp(player.recoilYaw, 0, Math.min(1, dt * 9));

  // FOV (ADS)
  const w = curWeapon();
  const targetFov = player.ads ? 75 / w.zoom : 75;
  camera.fov = lerp(camera.fov, targetFov, Math.min(1, dt * 12));
  camera.updateProjectionMatrix();

  // покачивание
  const spd = Math.hypot(player.vel.x, player.vel.z);
  player.bobT += dt * (4 + spd * 1.4);
  const bobAmt = player.onGround ? Math.min(spd / 7, 1) * 0.032 : 0;
  player.bob = Math.sin(player.bobT * 2) * bobAmt;
  const swayX = Math.sin(player.bobT) * bobAmt * 0.8;

  // позиция оружия
  const g = loadout.models[loadout.list[loadout.index]];
  if (!g) return;
  const adsP = player.adsT;
  const basePos = new V3(0.235, -0.215, -0.63);
  const adsPos = new V3(0, -0.075 * (w.type === 'sniper' ? 1.05 : 1), -0.42);
  const target = basePos.lerp(adsPos.clone(), adsP);
  target.x += swayX * (1 - adsP * .8);
  target.y += Math.cos(player.bobT * 2) * bobAmt * (1 - adsP * .85) - (loadout.switchT > 0 ? loadout.switchT * 0.9 : 0);
  gunHolder.position.lerp(target, Math.min(1, dt * 14));
  const rotTarget = new V3(
    -player.recoilPitch * 1.6 + Math.cos(player.bobT * 2) * bobAmt * 0.4,
    -player.recoilYaw * 1.2 + swayX * 0.6,
    0
  );
  gunHolder.rotation.x = lerp(gunHolder.rotation.x, rotTarget.x, Math.min(1, dt * 12));
  gunHolder.rotation.y = lerp(gunHolder.rotation.y, rotTarget.y, Math.min(1, dt * 12));
  gunHolder.position.z += player.recoilPitch * 0.6;
}

/* --------------------------------------------------------------- INPUT ---- */
const keys = {};
let pointerLocked = false, everLocked = false;
let mouseDown = false;
const mousePos = { x: innerWidth / 2, y: innerHeight / 2 };
let touchMode = new URLSearchParams(location.search).has('android') || navigator.maxTouchPoints > 0 || ('ontouchstart' in window);

addEventListener('keydown', e => {
  keys[e.code] = true;
  if (e.code === 'Escape') {
    if (gameState === 'play' && !paused) setPaused(true);
  }
  if (gameState !== 'play' || paused) return;
  if (e.code === 'KeyR') startReload();
  if (e.code === 'Digit1') selectWeapon(0);
  if (e.code === 'Digit2') selectWeapon(1);
  if (e.code === 'Digit3') selectWeapon(2);
  if (e.code === 'KeyP') godMode = !godMode;
  if (e.code === 'Space' && player.onGround && player.alive) {
    player.jumpVel = 4.6; player.onGround = false;
  }
  if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) e.preventDefault();
});
addEventListener('keyup', e => { keys[e.code] = false; });

function requestLock() {
  if (touchMode || pointerLocked) return;
  try {
    const r = canvas.requestPointerLock && canvas.requestPointerLock();
    if (r && r.catch) r.catch(() => {});
  } catch (err) { /* в iframe может быть запрещено — играем без захвата */ }
}

canvas.addEventListener('mousedown', e => {
  if (gameState !== 'play' || paused) return;
  requestLock();
  if (e.button === 0) { mouseDown = true; tryFire(); }
  if (e.button === 2) { player.ads = true; }
});
addEventListener('mouseup', e => {
  if (e.button === 0) mouseDown = false;
  if (e.button === 2) player.ads = false;
});
canvas.addEventListener('contextmenu', e => e.preventDefault());

addEventListener('mousemove', e => {
  mousePos.x = e.clientX; mousePos.y = e.clientY;
  if (gameState !== 'play' || paused) return;
  if (!pointerLocked) return; // без захвата обзор ведёт край экрана (см. updateMouseLook)
  const sens = 0.0021 * (player.ads ? 0.55 : 1);
  player.yaw -= e.movementX * sens;
  player.pitch -= e.movementY * sens;
  player.pitch = clamp(player.pitch, -Math.PI / 2 + 0.05, Math.PI / 2 - 0.05);
});

document.addEventListener('pointerlockchange', () => {
  pointerLocked = document.pointerLockElement === canvas;
  if (pointerLocked) everLocked = true;
  // пауза только если захват реально был и потерян (Esc)
  if (!pointerLocked && everLocked && gameState === 'play' && !paused && !touchMode) setPaused(true);
});

// обзор без захвата мыши: чем дальше курсор от центра, тем быстрее поворот
function updateMouseLook(dt) {
  if (pointerLocked || touchMode || !player.alive) return;
  const cx = innerWidth / 2, cy = innerHeight / 2;
  const nx = (mousePos.x - cx) / cx, ny = (mousePos.y - cy) / cy;
  const dead = 0.06;
  const ax = Math.abs(nx) < dead ? 0 : (nx - Math.sign(nx) * dead) / (1 - dead);
  const ay = Math.abs(ny) < dead ? 0 : (ny - Math.sign(ny) * dead) / (1 - dead);
  const rate = 2.4 * (player.ads ? 0.45 : 1);
  player.yaw -= ax * ax * Math.sign(ax) * rate * dt;
  player.pitch = clamp(player.pitch - ay * ay * Math.sign(ay) * rate * dt, -1.5, 1.5);
}

/* -------------------------------------------------------- MOBILE TOUCH ---- */
const touchState = { move: { x: 0, y: 0, active: false, id: null, ox: 0, oy: 0 }, look: { id: null, x: 0, y: 0 } };
function setupTouch() {
  if (!touchMode) return;
  const ui = document.createElement('div');
  ui.id = 'touchUI';
  ui.style.cssText = 'position:fixed;inset:0;z-index:8;pointer-events:none;color:white;font-family:Arial,sans-serif;touch-action:none;';
  ui.innerHTML = `
    <div id="stick" style="position:absolute;left:max(12px, env(safe-area-inset-left));bottom:12px;width:110px;height:110px;border-radius:50%;
      border:2px solid rgba(255,255,255,.25);background:rgba(0,0,0,.25);pointer-events:auto">
      <div id="stickKnob" style="position:absolute;left:50%;top:50%;width:54px;height:54px;margin:-27px 0 0 -27px;
        border-radius:50%;background:rgba(255,176,32,.55);border:2px solid rgba(255,255,255,.5)"></div>
    </div>
    <div id="btnFire" style="position:absolute;right:max(12px, env(safe-area-inset-right));bottom:16px;width:82px;height:82px;border-radius:50%;
      background:rgba(255,60,40,.35);border:2px solid rgba(255,90,60,.8);pointer-events:auto;display:flex;
      align-items:center;justify-content:center;font-size:11px;letter-spacing:1px">ОГОНЬ</div>
    <div id="btnReload" style="position:absolute;right:108px;bottom:25px;width:58px;height:58px;border-radius:50%;
      background:rgba(255,255,255,.12);border:2px solid rgba(255,255,255,.35);pointer-events:auto;display:flex;
      align-items:center;justify-content:center;font-size:10px">R</div>
    <div id="btnADS" style="position:absolute;right:max(18px, env(safe-area-inset-right));bottom:112px;width:58px;height:58px;border-radius:50%;
      background:rgba(255,255,255,.12);border:2px solid rgba(255,255,255,.35);pointer-events:auto;display:flex;
      align-items:center;justify-content:center;font-size:10px">ПРИЦЕЛ</div>`;
  document.body.appendChild(ui);

  const stick = document.getElementById('stick'), knob = document.getElementById('stickKnob');
  const R = 46;
  stick.addEventListener('touchstart', ev => {
    const t = ev.changedTouches[0]; touchState.move.id = t.identifier; touchState.move.active = true;
    const r = stick.getBoundingClientRect();
    touchState.move.ox = r.left + r.width / 2; touchState.move.oy = r.top + r.height / 2;
    ev.preventDefault();
  }, { passive: false });
  const moveHandler = ev => {
    for (const t of ev.changedTouches) {
      if (t.identifier === touchState.move.id) {
        let dx = (t.clientX - touchState.move.ox) / R, dy = (t.clientY - touchState.move.oy) / R;
        const l = Math.hypot(dx, dy); if (l > 1) { dx /= l; dy /= l; }
        touchState.move.x = dx; touchState.move.y = dy;
        knob.style.transform = 'translate(' + dx * R + 'px,' + dy * R + 'px)';
      }
    }
  };
  stick.addEventListener('touchmove', ev => { moveHandler(ev); ev.preventDefault(); }, { passive: false });
  const stickEnd = ev => {
    for (const t of ev.changedTouches) if (t.identifier === touchState.move.id) {
      touchState.move.id = null; touchState.move.active = false; touchState.move.x = touchState.move.y = 0;
      knob.style.transform = 'translate(0,0)';
    }
  };
  stick.addEventListener('touchend', stickEnd);
  stick.addEventListener('touchcancel', stickEnd);

  const fireBtn = document.getElementById('btnFire');
  fireBtn.addEventListener('touchstart', ev => { mouseDown = true; tryFire(); ev.preventDefault(); }, { passive: false });
  fireBtn.addEventListener('touchend', ev => { mouseDown = false; ev.preventDefault(); }, { passive: false });
  fireBtn.addEventListener('touchcancel', () => { mouseDown = false; });
  document.getElementById('btnReload').addEventListener('touchstart', ev => { startReload(); ev.preventDefault(); }, { passive: false });
  const adsBtn = document.getElementById('btnADS');
  adsBtn.addEventListener('touchstart', ev => { player.ads = true; ev.preventDefault(); }, { passive: false });
  adsBtn.addEventListener('touchend', ev => { player.ads = false; ev.preventDefault(); }, { passive: false });
  adsBtn.addEventListener('touchcancel', () => { player.ads = false; });

  // обзор правой частью
  canvas.addEventListener('touchstart', ev => {
    for (const t of ev.changedTouches) {
      if (t.clientX > innerWidth * 0.35) { touchState.look.id = t.identifier; touchState.look.x = t.clientX; touchState.look.y = t.clientY; }
    }
  }, { passive: true });
  canvas.addEventListener('touchmove', ev => {
    for (const t of ev.changedTouches) {
      if (t.identifier === touchState.look.id) {
        const dx = t.clientX - touchState.look.x, dy = t.clientY - touchState.look.y;
        touchState.look.x = t.clientX; touchState.look.y = t.clientY;
        player.yaw -= dx * 0.0055;
        player.pitch = clamp(player.pitch - dy * 0.0055, -1.5, 1.5);
      }
    }
    ev.preventDefault();
  }, { passive: false });
  canvas.addEventListener('touchend', ev => {
    for (const t of ev.changedTouches) if (t.identifier === touchState.look.id) touchState.look.id = null;
  }, { passive: true });
}

/* ---------------------------------------------------------- PLAYER SIM ---- */
function updatePlayer(dt) {
  if (!player.alive) return;
  let ix = 0, iz = 0;
  if (keys['KeyW'] || keys['ArrowUp']) iz -= 1;
  if (keys['KeyS'] || keys['ArrowDown']) iz += 1;
  if (keys['KeyA'] || keys['ArrowLeft']) ix -= 1;
  if (keys['KeyD'] || keys['ArrowRight']) ix += 1;
  if (touchMode) { ix += touchState.move.x; iz += touchState.move.y; }

  const len = Math.hypot(ix, iz);
  if (len > 1) { ix /= len; iz /= len; }

  player.crouch = !!(keys['ControlLeft'] || keys['ControlRight'] || keys['KeyC']);
  const wantSprint = (keys['ShiftLeft'] || keys['ShiftRight']) && iz < -0.2 && !player.crouch && !player.ads && len > 0.1;
  player.sprinting = wantSprint && player.stamina > 0.02;
  if (player.sprinting) player.stamina = Math.max(0, player.stamina - dt * 0.32);
  else player.stamina = Math.min(1, player.stamina + dt * 0.22);
  document.getElementById('stam').style.transform = 'scaleX(' + player.stamina + ')';

  let speed = 5.4;
  if (player.sprinting) speed = 8.6;
  if (player.crouch) speed = 2.6;
  if (player.ads) speed = 3.4;

  const sinY = Math.sin(player.yaw), cosY = Math.cos(player.yaw);
  const dirX = ix * cosY + iz * sinY;
  const dirZ = -ix * sinY + iz * cosY;

  const accel = 14;
  player.vel.x = lerp(player.vel.x, dirX * speed, Math.min(1, accel * dt));
  player.vel.z = lerp(player.vel.z, dirZ * speed, Math.min(1, accel * dt));

  resolveMove(player.pos, player.vel.x * dt, player.vel.z * dt, PLAYER_R);

  // прыжок
  if (!player.onGround) {
    player.jumpVel -= 13 * dt;
    player.jumpY = (player.jumpY || 0) + player.jumpVel * dt;
    if (player.jumpY <= 0) { player.jumpY = 0; player.onGround = true; player.jumpVel = 0; }
  } else player.jumpY = 0;

  // приседание плавно
  player.crouchT = lerp(player.crouchT, player.crouch ? 1 : 0, Math.min(1, dt * 12));
  player.height = lerp(1.7, 1.2, player.crouchT);

  // ADS плавно
  player.adsT = lerp(player.adsT, player.ads ? 1 : 0, Math.min(1, dt * 12));

  // автоматический огонь
  if (mouseDown && player.alive) {
    const w = curWeapon();
    if (w.auto) tryFire();
  }
}

/* ------------------------------------------------------------- HUD/MAP ---- */
const mm = document.getElementById('minimap');
const mctx = mm.getContext('2d');
function drawMinimap() {
  const W = mm.width, H = mm.height;
  const scale = W / (ARENA * 2.2);
  mctx.clearRect(0, 0, W, H);
  mctx.save();
  mctx.translate(W / 2, H / 2);
  mctx.scale(scale, scale);
  mctx.translate(-player.pos.x, -player.pos.z);
  // контейнеры/укрытия
  mctx.fillStyle = 'rgba(120,140,150,.28)';
  for (let i = 0; i < colliders.length; i++) {
    const c = colliders[i];
    mctx.fillRect(c.minx, c.minz, c.maxx - c.minx, c.maxz - c.minz);
  }
  // стены
  mctx.strokeStyle = 'rgba(255,176,32,.35)'; mctx.lineWidth = 3 / scale;
  mctx.strokeRect(-ARENA, -ARENA, ARENA * 2, ARENA * 2);
  // враги
  for (const e of enemies) {
    if (!e.alive) continue;
    const dx = e.root.position.x - player.pos.x, dz = e.root.position.z - player.pos.z;
    const d = Math.hypot(dx, dz);
    if (d > 55) continue;
    // без wallhack: на радаре только видимые цели (или вплотную)
    if (!e.seen && d > 7) continue;
    mctx.fillStyle = e.seen ? '#ff3b30' : 'rgba(255,60,48,.45)';
    mctx.beginPath(); mctx.arc(e.root.position.x, e.root.position.z, 7 / scale, 0, 7); mctx.fill();
  }
  mctx.restore();
  // игрок в центре
  mctx.save();
  mctx.translate(W / 2, H / 2);
  mctx.rotate(-player.yaw);
  mctx.fillStyle = '#39d7ff';
  mctx.beginPath(); mctx.moveTo(0, -11); mctx.lineTo(8, 8); mctx.lineTo(0, 4); mctx.lineTo(-8, 8);
  mctx.closePath(); mctx.fill();
  mctx.restore();
  // рамка
  mctx.strokeStyle = 'rgba(255,176,32,.25)'; mctx.lineWidth = 2;
  mctx.strokeRect(1, 1, W - 2, H - 2);
}

function updateHudDynamic(dt) {
  document.getElementById('score').textContent = stats.score;
  // прицел: расходится при движении
  const spr = currentSpread();
  const px = clamp(spr * 2200, 0, 26);
  const cross = document.getElementById('cross');
  cross.style.opacity = player.ads && curWeapon().type !== 'shotgun' ? '0.15' : '1';
  const its = cross.querySelectorAll('i');
  its[0].style.transform = 'translateY(' + (-px * 0.25) + 'px)';
  its[1].style.transform = 'translateY(' + (px * 0.25) + 'px)';
  its[2].style.transform = 'translateX(' + (-px * 0.25) + 'px)';
  its[3].style.transform = 'translateX(' + (px * 0.25) + 'px)';
  if (hitT > 0) { hitT -= dt; if (hitT <= 0) hitmarkEl.style.opacity = '0'; }
  drawMinimap();
}

/* --------------------------------------------------------------- GAME ---- */
let lastT = performance.now();
function loop() {
  requestAnimationFrame(loop);
  const now = performance.now();
  let dt = (now - lastT) / 1000;
  lastT = now;
  dt = Math.min(dt, 0.05);

  if (gameState === 'play' && !paused) {
    updateMouseLook(dt);
    updatePlayer(dt);
    updateEnemies(dt);
    updateWaves(dt);
    updateParticles(dt);
    updateCamera(dt);
    updateHudDynamic(dt);

    if (fireCooldown > 0) fireCooldown -= dt;
    if (loadout.switchT > 0) loadout.switchT -= dt;
    if (reloading > 0) { reloading -= dt; if (reloading <= 0) finishReload(); }

    // мультяшная отдача модели
    const mdl = loadout.models[loadout.list[loadout.index]];
    if (mdl) {
      mdl.position.z = lerp(mdl.position.z, 0, Math.min(1, dt * 12));
      if (mdl.userData.flashTimer > 0) {
        mdl.userData.flashTimer -= dt;
        if (mdl.userData.flashTimer <= 0 && mdl.userData.flash) mdl.userData.flash.visible = false;
      }
    }
    muzzleLight.intensity = lerp(muzzleLight.intensity, 0, Math.min(1, dt * 18));

    // трассеры
    for (const t of tracerPool) {
      if (t.life > 0) { t.life -= dt; t.line.material.opacity = Math.max(0, t.life / 0.075) * 0.9; if (t.life <= 0) t.line.visible = false; }
    }
  }

  renderer.autoClear = true;
  renderer.render(scene, camera);
  renderer.autoClear = false;
  renderer.clearDepth();
  renderer.render(gunScene, gunCam);
  renderer.autoClear = true;
}
loop();

/* ---------------------------------------------------------- GAME FLOW ---- */
function resetGame(primaryId) {
  // очистка врагов
  enemies.slice().forEach(e => enemyGroupRoot.remove(e.root));
  enemies.length = 0;
  enemyHitMeshes.length = 0;
  stats.score = 0; stats.kills = 0; stats.headshots = 0;
  wave = 0; waveState = 'idle'; toSpawn = 0;
  player.pos.set(0, 0, 0);
  player.yaw = 0; player.pitch = 0; player.vel.set(0, 0, 0);
  player.hp = player.maxHp; player.stamina = 1; player.alive = true;
  player.ads = false; player.adsT = 0; player.jumpY = 0; player.crouch = false;
  player.recoilPitch = player.recoilYaw = 0;
  Object.keys(WSTATE).forEach(k => delete WSTATE[k]);
  initLoadout(primaryId, 'pistol');
  updateHealthHud();
  updateAmmoHud();
  document.getElementById('score').textContent = '0';
  document.getElementById('wave').textContent = '1';
  document.getElementById('feed').innerHTML = '';
  startWave();
}

function startGame() {
  AudioSys.init();
  resetGame(selectedPrimary);
  gameState = 'play'; paused = false;
  document.getElementById('menu').classList.remove('on');
  document.getElementById('dead').classList.remove('on');
  document.getElementById('pause').classList.remove('on');
  document.getElementById('hud').classList.add('on');
  document.body.style.cursor = 'none';
  requestLock();
  lastT = performance.now();
}

function die() {
  if (!player.alive) return;
  player.alive = false;
  gameState = 'dead';
  document.getElementById('dWave').textContent = wave;
  document.getElementById('dScore').textContent = stats.score;
  document.getElementById('dKills').textContent = stats.kills;
  document.getElementById('dHs').textContent = stats.headshots;
  document.getElementById('deadSub').textContent = stats.kills > 9
    ? 'Неплохо, братик! Волна ' + wave + ' — это уже серьёзно 🌹'
    : 'Бывает. Ещё разок, братик? 💪';
  document.getElementById('dead').classList.add('on');
  document.getElementById('hud').classList.remove('on');
  document.body.style.cursor = 'default';
  if (document.exitPointerLock) document.exitPointerLock();
  // камера падает
  let t = 0;
  const fall = () => {
    t += 0.016;
    camera.rotation.z = lerp(camera.rotation.z, 1.2, 0.12);
    camera.position.y = lerp(camera.position.y, 0.4, 0.1);
    renderer.render(scene, camera);
    if (t < 0.8) requestAnimationFrame(fall);
  };
  fall();
}

function setPaused(p) {
  paused = p;
  document.getElementById('pause').classList.toggle('on', p);
  document.getElementById('hud').classList.toggle('on', !p);
  if (p && document.exitPointerLock) document.exitPointerLock();
  if (!p) { lastT = performance.now(); requestLock(); }
}

function toMenu() {
  gameState = 'menu'; paused = false;
  document.getElementById('menu').classList.add('on');
  document.getElementById('pause').classList.remove('on');
  document.getElementById('dead').classList.remove('on');
  document.getElementById('hud').classList.remove('on');
  if (document.exitPointerLock) document.exitPointerLock();
}

/* ------------------------------------------------------------- MENU UI ---- */
let selectedPrimary = 'ak47';
let selectedDiff = 'normal';
const DIFF = {
  easy: { hp: 0.75, dmg: 0.7 }, normal: { hp: 1, dmg: 1 }, hard: { hp: 1.35, dmg: 1.45 }
};

const gp = document.getElementById('gunpick');
[['ak47', 'AK-47', 'универсал'], ['m4', 'M4', 'точный'], ['mp5', 'MP5', 'скорострел'], ['shotgun', 'ОБРЕЗ', 'близко'], ['sniper', 'AWP', 'снайпер']].forEach(g => {
  const b = document.createElement('button');
  b.innerHTML = '<b>' + g[1] + '</b><span>' + g[2] + '</span>';
  if (g[0] === selectedPrimary) b.classList.add('on');
  b.onclick = () => {
    selectedPrimary = g[0];
    [...gp.children].forEach(c => c.classList.remove('on'));
    b.classList.add('on');
  };
  gp.appendChild(b);
});

const dp = document.getElementById('diffpick');
[['easy', 'ЛЕГКО'], ['normal', 'НОРМА'], ['hard', 'ХАРДКОР']].forEach(d => {
  const b = document.createElement('button');
  b.textContent = d[1];
  if (d[0] === selectedDiff) b.classList.add('on');
  b.onclick = () => {
    selectedDiff = d[0];
    [...dp.children].forEach(c => c.classList.remove('on'));
    b.classList.add('on');
  };
  dp.appendChild(b);
});

document.getElementById('btnPlay').onclick = startGame;
document.getElementById('btnRetry').onclick = startGame;
document.getElementById('btnMenu2').onclick = toMenu;
document.getElementById('btnQuit').onclick = toMenu;
document.getElementById('btnResume').onclick = () => setPaused(false);
document.getElementById('btnSound').onclick = function () {
  AudioSys.init();
  const on = AudioSys.toggle();
  this.textContent = on ? '🔊 ЗВУК: ВКЛ' : '🔇 ЗВУК: ВЫКЛ';
  this.classList.toggle('on', !on);
};
document.getElementById('btnFull').onclick = () => {
  if (!document.fullscreenElement) document.documentElement.requestFullscreen && document.documentElement.requestFullscreen();
  else document.exitFullscreen && document.exitFullscreen();
};

// сложность применяется при спавне
const _spawnOne = spawnOne;
spawnOne = function () {
  const before = enemies.length;
  const ok = _spawnOne();
  if (ok && enemies.length > before) {
    const e = enemies[enemies.length - 1];
    const d = DIFF[selectedDiff] || DIFF.normal;
    e.hp = Math.round(e.hp * d.hp); e.maxHp = e.hp;
    e.dmg *= d.dmg;
  }
  return ok;
};

addEventListener('resize', () => {
  renderer.setSize(innerWidth, innerHeight);
  camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix();
  gunCam.aspect = innerWidth / innerHeight; gunCam.updateProjectionMatrix();
});

setupTouch();
if (touchMode) {
  const hintEl = document.getElementById('hint');
  hintEl.textContent = 'Стик слева — движение, справа — обзор. Кнопка ОГОНЬ — стрелять.';
  setTimeout(() => { hintEl.style.opacity = '0'; }, 7000);
}

// показать оружие в меню (крутится)
initLoadout('ak47', 'pistol');
updateHealthHud();
window.__GAME__ = { player, enemies, stats, WEAPONS, scene, camera, renderer, colliders, hasLOS };

// мосты для Android-обёртки (кнопка "назад" = пауза)
window.__PAUSE__ = function () {
  if (gameState === 'play' && !paused) setPaused(true);
};
window.__RESUME__ = function () {
  if (gameState === 'play' && paused) setPaused(false);
};
window.__IS_PAUSED__ = function () { return paused; };
})();
