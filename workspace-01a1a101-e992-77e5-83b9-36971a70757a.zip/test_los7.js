const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox','--use-gl=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await b.newPage({ viewport: { width: 960, height: 540 } });
  page.on('pageerror', e => console.log('[PAGEERROR]', e.message));
  await page.goto('file:///home/user/bratik-ops.html');
  await page.waitForTimeout(1000);
  await page.click('#btnPlay');
  await page.waitForTimeout(6000);
  const r = await page.evaluate(async () => {
    const g = window.__GAME__;
    const e = g.enemies.find(x => x.alive);
    const sleep = ms => new Promise(r => setTimeout(r, ms));
    g.player.pos.set(-24, 0, -14);
    const log = [];
    for (let i = 0; i < 12; i++) {
      e.speed = 0; e.hp = e.maxHp * 0.4; e.root.position.set(-24, 0, -11);
      await sleep(100);
      log.push([+e.losT.toFixed(2), e.seen, e.hpBg.visible, e.alive]);
    }
    return { log, paused: document.getElementById('pause').classList.contains('on'), lock: !!document.pointerLockElement };
  });
  console.log(JSON.stringify(r));
  await b.close();
})();
