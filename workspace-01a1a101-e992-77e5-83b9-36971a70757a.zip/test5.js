const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox','--use-gl=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await b.newPage({ viewport: { width: 960, height: 540 } });
  page.on('pageerror', e => console.log('[PAGEERROR]', e.message));
  await page.goto('file:///home/user/bratik-ops.html');
  await page.waitForTimeout(1200);
  await page.click('#btnPlay');
  await page.waitForTimeout(1000);
  await page.evaluate(() => {
    const g = window.__GAME__;
    // держим врага прямо перед игроком
    g.__hold = setInterval(() => {
      g.enemies.forEach((e, i) => { if (e.alive) { e.root.position.set((i-1)*2.2, 0, -9); } });
    }, 30);
  });
  await page.waitForTimeout(500);
  await page.mouse.move(480, 270);
  await page.mouse.down();
  await page.waitForTimeout(900);
  await page.mouse.up();
  await page.waitForTimeout(800);
  await page.screenshot({ path: 'shots/kill.png' });
  const info = await page.evaluate(() => { const g = window.__GAME__; return { stats: g.stats, alive: g.enemies.filter(e=>e.alive).length, ammo: document.getElementById('ammo').textContent, feed: document.getElementById('feed').textContent }; });
  console.log(JSON.stringify(info));
  await b.close();
})();
