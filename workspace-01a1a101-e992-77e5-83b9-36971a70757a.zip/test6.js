const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox','--use-gl=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await b.newPage({ viewport: { width: 960, height: 540 } });
  page.on('pageerror', e => console.log('[PAGEERROR]', e.message));
  page.on('console', m => { if (m.text().startsWith('DBG')) console.log(m.text()); });
  await page.goto('file:///home/user/bratik-ops.html');
  await page.waitForTimeout(1200);
  await page.click('#btnPlay');
  await page.waitForTimeout(1500);
  const out = await page.evaluate(() => {
    const g = window.__GAME__;
    const c = g.camera;
    const e = g.enemies.find(x => x.alive);
    if (!e) return 'no enemies';
    e.root.position.set(0, 0, -9);
    e.root.updateMatrixWorld(true);
    const THREEc = c.constructor;
    const rc = new (Object.getPrototypeOf(g.scene).constructor.prototype.constructor === undefined ? null : window.THREE.Raycaster)();
    rc.far = 300;
    const origin = c.position.clone();
    const dir = new window.THREE.Vector3(0, 0, -1).applyQuaternion(c.quaternion);
    rc.set(origin, dir);
    const hits = rc.intersectObjects(g.scene.children, true);
    return { origin: origin.toArray(), dir: dir.toArray(), head: e.head.getWorldPosition(new window.THREE.Vector3()).toArray(),
      hits: hits.slice(0,5).map(h => ({ d: +h.distance.toFixed(2), type: h.object.type, enemy: !!(h.object.userData && h.object.userData.enemy), part: h.object.userData && h.object.userData.part })),
      camRot: [c.rotation.x, c.rotation.y, c.rotation.z] };
  });
  console.log(JSON.stringify(out, null, 1));
  await b.close();
})();
