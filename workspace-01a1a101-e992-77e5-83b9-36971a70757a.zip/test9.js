const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox','--use-gl=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await b.newPage({ viewport: { width: 960, height: 540 } });
  await page.goto('file:///home/user/bratik-ops.html');
  await page.waitForTimeout(1200);
  await page.click('#btnPlay');
  await page.waitForTimeout(1000);
  console.log('before', await page.evaluate(() => { const p = window.__GAME__.player; return [p.yaw.toFixed(3), p.pitch.toFixed(3)]; }));
  await page.mouse.move(480, 270);
  await page.mouse.down(); await page.waitForTimeout(400);
  console.log('after', await page.evaluate(() => { const p = window.__GAME__.player; return [p.yaw.toFixed(3), p.pitch.toFixed(3)]; }));
  await page.screenshot({ path: 'shots/a.png' });
  await page.evaluate(() => { const p = window.__GAME__.player; p.yaw = 0; p.pitch = 0; p.recoilPitch = 0; p.recoilYaw = 0; });
  await page.waitForTimeout(300);
  await page.screenshot({ path: 'shots/b.png' });
  await page.mouse.up();
  await b.close();
})();
