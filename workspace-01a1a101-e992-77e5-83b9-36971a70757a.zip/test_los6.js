const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox','--use-gl=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await b.newPage({ viewport: { width: 960, height: 540 } });
  page.on('pageerror', e => console.log('[PAGEERROR]', e.message));
  await page.goto('file:///home/user/bratik-ops.html');
  await page.waitForTimeout(1000);
  await page.click('#btnPlay');
  await page.waitForTimeout(6000);
  const r = await page.evaluate(async () => {
    const g = window.__GAME__, T = window.THREE;
    const e = g.enemies.find(x => x.alive);
    if (!e) return { err: 'no alive', n: g.enemies.length };
    const sleep = ms => new Promise(r => setTimeout(r, ms));
    g.player.pos.set(-24, 0, -14);
    g.__f = setInterval(() => { e.speed = 0; e.hp = e.maxHp * 0.4; e.root.position.set(-24, 0, -11); }, 25);
    await sleep(700);
    return { alive: e.alive, seen: e.seen, barVis: e.hpBg.visible, dist: +e.root.position.distanceTo(g.player.pos).toFixed(2),
      los: g.hasLOS(g.player.pos, e.root.position), n: g.enemies.length, fps: 'ok' };
  });
  console.log(JSON.stringify(r));
  await b.close();
})();
