const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox','--use-gl=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await b.newPage({ viewport: { width: 960, height: 540 } });
  await page.goto('file:///home/user/bratik-ops.html');
  await page.waitForTimeout(1000);
  await page.click('#btnPlay');
  await page.waitForTimeout(6000);
  const r = await page.evaluate(async () => {
    const g = window.__GAME__;
    const e = g.enemies[0];
    const sleep = ms => new Promise(r => setTimeout(r, ms));
    g.player.pos.set(-24, 0, -14); g.player.yaw = Math.PI; g.player.pitch = 0; // смотрим в +Z? нет: yaw=PI -> смотрим в +Z
    // за контейнером (контейнер z -19.4..-16.6)
    g.__f = setInterval(() => { e.speed = 0; e.root.position.set(-24, 0, -24); e.hp = e.maxHp * 0.4; }, 25);
    await sleep(600);
    const behind = { seen: e.seen, bar: e.hpBg.visible };
    clearInterval(g.__f);
    // на открытом месте перед игроком
    g.__f = setInterval(() => { e.speed = 0; e.root.position.set(-24, 0, -11); e.hp = e.maxHp * 0.4; }, 25);
    await sleep(600);
    const open = { seen: e.seen, bar: e.hpBg.visible };
    clearInterval(g.__f);
    return { behind, open };
  });
  console.log(JSON.stringify(r));
  await page.screenshot({ path: 'shots/los_final.png' });
  await b.close();
})();
