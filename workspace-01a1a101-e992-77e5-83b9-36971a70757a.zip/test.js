const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ args: ['--no-sandbox','--use-gl=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'] });
  const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
  const logs = [];
  page.on('console', m => logs.push('[' + m.type() + '] ' + m.text()));
  page.on('pageerror', e => logs.push('[PAGEERROR] ' + e.message));
  await page.goto('file:///home/user/bratik-ops.html');
  await page.waitForTimeout(2500);
  await page.screenshot({ path: 'shots/menu.png' });
  await page.click('#btnPlay');
  await page.waitForTimeout(1500);
  // simulate play: hold W and fire
  await page.keyboard.down('KeyW');
  await page.waitForTimeout(800);
  await page.keyboard.up('KeyW');
  await page.mouse.move(640,360); await page.mouse.down(); await page.waitForTimeout(600); await page.mouse.up();
  await page.waitForTimeout(4000);
  await page.screenshot({ path: 'shots/play1.png' });
  await page.waitForTimeout(5000);
  await page.screenshot({ path: 'shots/play2.png' });
  const info = await page.evaluate(() => {
    const g = window.__GAME__;
    return { hp: g.player.hp, enemies: g.enemies.length, alive: g.enemies.filter(e=>e.alive).length, stats: g.stats, camY: g.camera.position.y, pos: g.player.pos.toArray(), calls: g.renderer.info.render.calls, tris: g.renderer.info.render.triangles };
  });
  console.log(JSON.stringify(info));
  console.log(logs.slice(0,40).join('\n'));
  await browser.close();
})();
