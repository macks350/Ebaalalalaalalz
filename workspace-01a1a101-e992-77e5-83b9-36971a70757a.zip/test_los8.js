const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox','--use-gl=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await b.newPage({ viewport: { width: 960, height: 540 } });
  page.on('pageerror', e => console.log('[PAGEERROR]', e.message));
  await page.goto('file:///home/user/bratik-ops.html');
  await page.waitForTimeout(1000);
  await page.click('#btnPlay');
  await page.waitForTimeout(6000);
  const r = await page.evaluate(async () => {
    const g = window.__GAME__;
    const e = g.enemies.find(x => x.alive);
    const sleep = ms => new Promise(r => setTimeout(r, ms));
    g.player.pos.set(-24, 0, -14); g.player.yaw = Math.PI;
    // за контейнером
    for (let i = 0; i < 6; i++) { e.speed = 0; e.root.position.set(-24, 0, -24); e.hp = e.maxHp * 0.4; await sleep(100); }
    const behind = { seen: e.seen, bar: e.hpBg.visible };
    // открытая позиция
    for (let i = 0; i < 6; i++) { e.speed = 0; e.root.position.set(-24, 0, -11); e.hp = e.maxHp * 0.4; await sleep(100); }
    const open = { seen: e.seen, bar: e.hpBg.visible };
    return { behind, open };
  });
  console.log(JSON.stringify(r));
  await page.screenshot({ path: 'shots/los_check.png' });
  await b.close();
})();
