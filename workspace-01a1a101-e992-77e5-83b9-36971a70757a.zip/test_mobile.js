const { chromium, devices } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox','--use-gl=swiftshader','--enable-unsafe-swiftshader'] });
  const ctx = await b.newContext({ viewport: { width: 844, height: 390 }, hasTouch: true, isMobile: true, deviceScaleFactor: 2 });
  const page = await ctx.newPage();
  page.on('pageerror', e => console.log('[PAGEERROR]', e.message));
  await page.goto('file:///home/user/bratik-ops.html');
  await page.waitForTimeout(1500);
  await page.screenshot({ path: 'shots/m_menu.png' });
  await page.tap('#btnPlay');
  await page.waitForTimeout(2000);
  await page.screenshot({ path: 'shots/m_play.png' });
  const r = await page.evaluate(() => ({ touchUI: !!document.getElementById('touchUI'), hint: document.getElementById('hint').textContent, enemies: window.__GAME__.enemies.length, mode: ('ontouchstart' in window) && innerWidth < 1100 }));
  console.log(JSON.stringify(r));
  await b.close();
})();
