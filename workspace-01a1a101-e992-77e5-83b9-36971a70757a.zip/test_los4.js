const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox','--use-gl=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await b.newPage({ viewport: { width: 960, height: 540 } });
  await page.goto('file:///home/user/bratik-ops.html');
  await page.waitForTimeout(1000);
  await page.click('#btnPlay');
  await page.waitForTimeout(2500);
  const r = await page.evaluate(() => {
    const g = window.__GAME__, T = window.THREE;
    const p = g.player.pos;
    const samples = [[-24,-17.5],[-24,-22],[-20,-14],[0,-6],[10,0],[0,10],[-40,-40]];
    const los = samples.map(s => ({ to: s, los: g.hasLOS(p, new T.Vector3(s[0],0,s[1])) }));
    // какие препятствия рядом
    const near = g.colliders.filter(c => Math.abs((c.minx+c.maxx)/2 + 24) < 12 && Math.abs((c.minz+c.maxz)/2 + 18) < 12)
      .map(c => ({ x:[+c.minx.toFixed(1),+c.maxx.toFixed(1)], z:[+c.minz.toFixed(1),+c.maxz.toFixed(1)], h:+(c.h||0).toFixed(1) }));
    return { playerAt: p.toArray(), los, near };
  });
  console.log(JSON.stringify(r, null, 1));
  await b.close();
})();
