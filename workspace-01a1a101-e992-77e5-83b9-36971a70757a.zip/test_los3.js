const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox','--use-gl=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await b.newPage({ viewport: { width: 960, height: 540 } });
  page.on('pageerror', e => console.log('[PAGEERROR]', e.message));
  await page.goto('file:///home/user/bratik-ops.html');
  await page.waitForTimeout(1200);
  await page.click('#btnPlay');
  await page.waitForTimeout(3000);
  const r = await page.evaluate(async () => {
    const g = window.__GAME__;
    const e = g.enemies.find(x => x.alive);
    const sleep = ms => new Promise(r => setTimeout(r, ms));
    // "замораживаем" врага перед камерой
    g.__freeze = setInterval(() => {
      e.speed = 0;
      e.root.position.set(-24, 0, -22);   // за контейнером
      e.hp = e.maxHp * 0.4;
    }, 25);
    g.player.pos.set(-24, 0, -14);
    g.player.yaw = 0; g.player.pitch = 0;
    await sleep(700);
    const behind = { seen: e.seen, bar: e.hpBg.visible };
    clearInterval(g.__freeze);
    g.__freeze = setInterval(() => { e.speed = 0; e.root.position.set(-24, 0, -17.5); e.hp = e.maxHp * 0.4; }, 25);
    await sleep(700);
    const open = { seen: e.seen, bar: e.hpBg.visible };
    clearInterval(g.__freeze);
    return { behind, open };
  });
  console.log(JSON.stringify(r));
  await page.screenshot({ path: 'shots/los_ok.png' });
  await b.close();
})();
