#!/bin/bash
node -e "
const fs=require('fs');
let h=fs.readFileSync('src/index.html','utf8');
const three=fs.readFileSync('vendor/three.min.js','utf8').replace(/<\/script>/gi,'<\\\\/script>');
const game=(fs.readFileSync('src/gun_data.js','utf8')+'\n'+fs.readFileSync('src/game.js','utf8')).replace(/<\/script>/gi,'<\\\\/script>');
h=h.replace('/*__THREE__*/',()=>three).replace('/*__GAME__*/',()=>game);
fs.writeFileSync('bratik-ops.html',h);
console.log('built',(h.length/1024).toFixed(0)+' KB');
"
