const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox','--use-gl=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await b.newPage({ viewport: { width: 960, height: 540 } });
  page.on('pageerror', e => console.log('[PAGEERROR]', e.message));
  await page.goto('file:///home/user/bratik-ops.html');
  await page.waitForTimeout(1200);
  await page.click('#btnPlay');
  await page.waitForTimeout(4000);
  const r = await page.evaluate(async () => {
    const g = window.__GAME__;
    const e = g.enemies.find(x => x.alive);
    if (!e) return 'none';
    // 1) враг за контейнером: ставим стену между
    e.root.position.set(0, 0, -14);
    e.hp = e.maxHp * 0.4;
    const sleep = ms => new Promise(r => setTimeout(r, ms));
    await sleep(400);
    const behindCover = { seen: e.seen, bar: e.hpBg.visible };
    // 2) на открытом месте
    e.root.position.set(0, 0, -6);
    await sleep(400);
    const openField = { seen: e.seen, bar: e.hpBg.visible };
    return { behindCover, openField };
  });
  console.log(JSON.stringify(r));
  await b.close();
})();
