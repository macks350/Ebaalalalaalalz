import bpy
bpy.ops.wm.open_mainfile(filepath='gunpack/Blends/AssaultRifle_1.blend')
for o in bpy.data.objects:
 if o.type=='MESH':
  print('MATERIALS', [(m.name,list(m.diffuse_color)) for m in o.data.materials], 'tri material',set(p.material_index for p in o.data.polygons))
