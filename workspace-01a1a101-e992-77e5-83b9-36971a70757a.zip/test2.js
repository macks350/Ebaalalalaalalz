const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ args: ['--no-sandbox','--use-gl=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await browser.newPage({ viewport: { width: 960, height: 540 } });
  page.on('pageerror', e => console.log('[PAGEERROR]', e.message));
  page.on('console', m => { if(m.type()==='error') console.log('[err]', m.text()); });
  await page.goto('file:///home/user/bratik-ops.html');
  await page.waitForTimeout(2000);
  const r = await page.evaluate(() => {
    const g = window.__GAME__;
    const info = { children: g.scene.children.length, bg: g.scene.background, fog: !!g.scene.fog,
      camPos: g.camera.position.toArray(), camRot: [g.camera.rotation.x,g.camera.rotation.y,g.camera.rotation.z],
      gl: g.renderer.getContext() ? 'ok' : 'none' };
    // render scene only
    g.renderer.autoClear = true;
    g.camera.rotation.set(0,0,0);
    g.renderer.render(g.scene, g.camera);
    info.calls = g.renderer.info.render.calls; info.tris = g.renderer.info.render.triangles;
    info.glErr = g.renderer.getContext().getError();
    return info;
  });
  console.log(JSON.stringify(r,null,1));
  await page.screenshot({ path: 'shots/dbg.png' });
  await browser.close();
})();
