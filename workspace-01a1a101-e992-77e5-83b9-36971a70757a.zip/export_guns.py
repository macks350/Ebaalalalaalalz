import bpy,json,sys,os
p=sys.argv[sys.argv.index('--')+1]; out=sys.argv[sys.argv.index('--')+2]
bpy.ops.wm.open_mainfile(filepath=p)
parts=[]
for ob in bpy.data.objects:
 if ob.type != 'MESH':continue
 mesh=ob.data; mesh.calc_loop_triangles(); mw=ob.matrix_world
 verts=[list(mw @ v.co) for v in mesh.vertices]; faces=[list(t.vertices)+[t.material_index] for t in mesh.loop_triangles]; colors=[list(m.diffuse_color[:3]) if m else [0.2,0.2,0.2] for m in mesh.materials]
 if not faces:continue
 parts.append({'v':verts,'f':faces,'name':ob.name,'colors':colors})
print('PARTS',[(p['name'],len(p['v'])) for p in parts])
open(out,'w').write(json.dumps(parts,separators=(',',':')))
