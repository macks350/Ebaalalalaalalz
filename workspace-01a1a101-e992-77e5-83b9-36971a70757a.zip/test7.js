const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox','--use-gl=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await b.newPage({ viewport: { width: 960, height: 540 } });
  page.on('pageerror', e => console.log('[PAGEERROR]', e.message));
  await page.goto('file:///home/user/bratik-ops.html');
  await page.waitForTimeout(1200);
  await page.click('#btnPlay');
  await page.waitForTimeout(4000);
  const out = await page.evaluate(() => {
    const g = window.__GAME__, T = window.THREE;
    const e = g.enemies.find(x => x.alive);
    if (!e) return 'no enemies: ' + g.enemies.length;
    e.root.position.set(0, 0, -9); e.root.updateMatrixWorld(true);
    const c = g.camera;
    const rc = new T.Raycaster(); rc.far = 300;
    const dir = new T.Vector3(0, 0, -1).applyQuaternion(c.quaternion);
    rc.set(c.position.clone(), dir);
    // все меши сцены
    const all = []; g.scene.traverse(o => { if (o.isMesh) all.push(o); });
    const hits = rc.intersectObjects(all, false);
    return {
      cenemies: g.enemies.length,
      head: e.head.getWorldPosition(new T.Vector3()).toArray().map(v=>+v.toFixed(2)),
      cam: c.position.toArray().map(v=>+v.toFixed(2)),
      rots: [c.rotation.x, c.rotation.y, c.rotation.z].map(v=>+v.toFixed(3)),
      hits: hits.slice(0,6).map(h => ({ d: +h.distance.toFixed(2), enemy: !!(h.object.userData&&h.object.userData.enemy), part: h.object.userData&&h.object.userData.part, geo: h.object.geometry.type })),
      visible: e.root.visible, parentVisible: e.root.parent && e.root.parent.visible
    };
  });
  console.log(JSON.stringify(out, null, 1));
  await b.close();
})();
