const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox','--use-gl=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await b.newPage({ viewport: { width: 960, height: 540 } });
  page.on('pageerror', e => console.log('[PAGEERROR]', e.message));
  await page.goto('file:///home/user/bratik-ops.html');
  await page.waitForTimeout(1200);
  await page.click('#btnPlay');
  await page.waitForTimeout(3500);
  const r = await page.evaluate(async () => {
    const g = window.__GAME__;
    const e = g.enemies.find(x => x.alive);
    const sleep = ms => new Promise(r => setTimeout(r, ms));
    // игрок и враг по разные стороны контейнера (-24,-18)
    g.player.pos.set(-24, 0, -14);
    e.root.position.set(-24, 0, -22);
    e.hp = e.maxHp * 0.4;
    await sleep(500);
    const behind = { seen: e.seen, bar: e.hpBg.visible };
    // выходим из-за укрытия
    e.root.position.set(-20, 0, -14);
    await sleep(500);
    const side = { seen: e.seen, bar: e.hpBg.visible };
    return { behind, side };
  });
  console.log(JSON.stringify(r));
  await page.screenshot({ path: 'shots/los.png' });
  await b.close();
})();
