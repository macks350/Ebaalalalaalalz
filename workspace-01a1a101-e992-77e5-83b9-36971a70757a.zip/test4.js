const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox','--use-gl=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await b.newPage({ viewport: { width: 960, height: 540 } });
  page.on('pageerror', e => console.log('[PAGEERROR]', e.message));
  await page.goto('file:///home/user/bratik-ops.html');
  await page.waitForTimeout(1500);
  await page.click('#btnPlay');
  await page.waitForTimeout(1200);
  await page.screenshot({ path: 'shots/v1.png' });
  // поставить врагов рядом и посмотреть на них
  const r = await page.evaluate(() => {
    const g = window.__GAME__;
    const e = g.enemies[0];
    if (e) { e.root.position.set(0, 0, -8); }
    return { n: g.enemies.length };
  });
  console.log(JSON.stringify(r));
  await page.waitForTimeout(600);
  await page.screenshot({ path: 'shots/enemy.png' });
  // стреляем 2 секунды
  await page.mouse.down(); await page.waitForTimeout(1500); await page.mouse.up();
  await page.waitForTimeout(1200);
  await page.screenshot({ path: 'shots/shoot.png' });
  const info = await page.evaluate(() => { const g = window.__GAME__; return { hp: g.player.hp.toFixed(0), stats: g.stats, alive: g.enemies.filter(e=>e.alive).length, n: g.enemies.length }; });
  console.log(JSON.stringify(info));
  await b.close();
})();
