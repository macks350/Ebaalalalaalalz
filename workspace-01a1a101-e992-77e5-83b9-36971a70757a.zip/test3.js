const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ args: ['--no-sandbox','--use-gl=swiftshader','--enable-unsafe-swiftshader'] });
  const page = await browser.newPage({ viewport: { width: 960, height: 540 } });
  page.on('pageerror', e => console.log('[PAGEERROR]', e.message));
  await page.goto('file:///home/user/bratik-ops.html');
  await page.waitForTimeout(1500);
  await page.click('#btnPlay');
  await page.waitForTimeout(2500);
  const info = await page.evaluate(() => { const g = window.__GAME__; return {cam: g.camera.position.toArray(), rot:[g.camera.rotation.x,g.camera.rotation.y], enemies: g.enemies.length, lights: g.scene.children.filter(c=>c.isLight).length }; });
  console.log(JSON.stringify(info));
  await page.screenshot({ path: 'shots/play_a.png' });
  await browser.close();
})();
