#!/bin/bash
set -e
export JAVA_HOME=/home/user/android/jdk17
export PATH=/home/user/android/jdk17/bin:$PATH
SDK=/home/user/android/sdk
BT=$SDK/build-tools/34.0.0
PLAT=$SDK/platforms/android-34/android.jar
APP=/home/user/android/app
OUT=/home/user/android/out
rm -rf $OUT && mkdir -p $OUT/compiled $OUT/classes $OUT/dex

echo "== 1. aapt2 compile resources"
$BT/aapt2 compile --dir $APP/res -o $OUT/compiled/res.zip

echo "== 2. aapt2 link (manifest, assets)"
$BT/aapt2 link -o $OUT/base.apk \
  -I $PLAT \
  --manifest $APP/AndroidManifest.xml \
  -A $APP/assets \
  --java $OUT/gen \
  --min-sdk-version 24 --target-sdk-version 34 \
  --version-code 1 --version-name 1.0 \
  $OUT/compiled/res.zip

echo "== 3. javac"
mkdir -p $OUT/gen
$JAVA_HOME/bin/javac -source 1.8 -target 1.8 -nowarn -encoding UTF-8 \
  -bootclasspath $PLAT -classpath $PLAT \
  -d $OUT/classes \
  $(find $APP/src -name '*.java') $(find $OUT/gen -name '*.java' 2>/dev/null) 2>&1 | grep -v "bootstrap class path" || true

echo "== 4. d8 -> dex"
$BT/d8 --lib $PLAT --min-api 24 --output $OUT/dex $(find $OUT/classes -name '*.class')

echo "== 5. упаковка"
cp $OUT/base.apk $OUT/unsigned.apk
cd $OUT/dex && zip -q -X ../unsigned.apk classes.dex && cd $OUT

echo "== 6. zipalign"
$BT/zipalign -f -p 4 $OUT/unsigned.apk $OUT/aligned.apk

echo "== 7. подпись"
if [ ! -f /home/user/android/keystore.jks ]; then
  $JAVA_HOME/bin/keytool -genkeypair -v -keystore /home/user/android/keystore.jks \
    -alias bratik -keyalg RSA -keysize 2048 -validity 10950 \
    -storetype JKS -storepass bratik123 -keypass bratik123 \
    -dname "CN=Bratik Ops, OU=Games, O=Bratik, L=Manila, C=PH" > /dev/null 2>&1
fi
$BT/apksigner sign --ks /home/user/android/keystore.jks --ks-pass pass:bratik123 --key-pass pass:bratik123 \
  --out /home/user/BratikOps.apk $OUT/aligned.apk
$BT/apksigner verify --print-certs /home/user/BratikOps.apk | head -4
ls -lh /home/user/BratikOps.apk
